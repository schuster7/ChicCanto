
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/redeem.js
import crypto from "node:crypto";

// netlify/functions/_db.js
import { getStore } from "@netlify/blobs";
var mem = {
  tokens: /* @__PURE__ */ new Map(),
  orders: /* @__PURE__ */ new Map()
};
function tryBlobStores() {
  try {
    return {
      tokens: getStore({ name: "chiccanto_tokens", consistency: "strong" }),
      orders: getStore({ name: "chiccanto_orders", consistency: "strong" })
    };
  } catch (e) {
    return null;
  }
}
var _stores = null;
function stores() {
  if (_stores) return _stores;
  const blob = tryBlobStores();
  _stores = blob ?? {
    tokens: {
      async get(key) {
        return mem.tokens.has(key) ? mem.tokens.get(key) : null;
      },
      async set(key, value) {
        mem.tokens.set(key, value);
      },
      async delete(key) {
        mem.tokens.delete(key);
      }
    },
    orders: {
      async get(key) {
        return mem.orders.has(key) ? mem.orders.get(key) : null;
      },
      async set(key, value) {
        mem.orders.set(key, value);
      },
      async delete(key) {
        mem.orders.delete(key);
      }
    }
  };
  return _stores;
}
async function getTokenRecord(token) {
  const { tokens } = stores();
  const value = await tokens.get(token);
  if (!value) return null;
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}
async function setTokenRecord(token, record) {
  const { tokens } = stores();
  await tokens.set(token, JSON.stringify(record));
}
async function getOrderRecord(code) {
  const { orders } = stores();
  const value = await orders.get(code);
  if (!value) return null;
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}
async function setOrderRecord(code, record) {
  const { orders } = stores();
  await orders.set(code, JSON.stringify(record));
}

// netlify/functions/redeem.js
function json(status, obj) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store"
    }
  });
}
function makeTokenFromString(seed) {
  const hash = crypto.createHash("sha1").update(seed).digest("hex");
  const short = hash.slice(0, 12);
  return `${short.slice(0, 8)}-${short.slice(8)}`;
}
function base64url(bytes) {
  return Buffer.from(bytes).toString("base64url");
}
async function ensureTokenForOrder(orderCode, index, init) {
  const token = makeTokenFromString(`${orderCode}:${index}:${init.product_id}`);
  const existing = await getTokenRecord(token);
  if (existing) {
    return { token, setup_key: existing.setup_key, product_id: existing.product_id };
  }
  const setup_key = base64url(crypto.randomBytes(16));
  const card = {
    version: 1,
    token,
    product_id: init.product_id,
    theme_id: init.theme_id || "default",
    fields: init.fields || {},
    setup_key,
    created_at: Date.now(),
    configured: false,
    outcome_mode: "we_pick"
  };
  await setTokenRecord(token, card);
  return { token, setup_key, product_id: init.product_id };
}
async function handler(request) {
  if (request.method !== "POST") {
    return json(405, { ok: false, error: "Method not allowed" });
  }
  let body;
  try {
    body = await request.json();
  } catch {
    return json(400, { ok: false, error: "Invalid JSON" });
  }
  const code = (body?.code || "").toString().trim();
  const init = body?.init;
  if (!code) return json(400, { ok: false, error: "Missing code" });
  if (!init || typeof init !== "object" || !init.product_id) {
    return json(400, { ok: false, error: "Missing init" });
  }
  const requestedInits = [init];
  const existingOrder = await getOrderRecord(code);
  if (existingOrder?.cards?.length) {
    return json(200, { ok: true, existing: true, cards: existingOrder.cards });
  }
  const cards = [];
  for (let i = 0; i < requestedInits.length; i++) {
    const c = await ensureTokenForOrder(code, i + 1, requestedInits[i]);
    cards.push(c);
  }
  await setOrderRecord(code, { code, created_at: Date.now(), cards });
  return json(200, { ok: true, existing: false, cards });
}
export {
  handler as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibmV0bGlmeS9mdW5jdGlvbnMvcmVkZWVtLmpzIiwgIm5ldGxpZnkvZnVuY3Rpb25zL19kYi5qcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IGNyeXB0byBmcm9tICdub2RlOmNyeXB0byc7XG5pbXBvcnQgeyBnZXRPcmRlclJlY29yZCwgc2V0T3JkZXJSZWNvcmQsIGdldFRva2VuUmVjb3JkLCBzZXRUb2tlblJlY29yZCB9IGZyb20gJy4vX2RiLmpzJztcblxuZnVuY3Rpb24ganNvbihzdGF0dXMsIG9iail7XG4gIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkob2JqKSwge1xuICAgIHN0YXR1cyxcbiAgICBoZWFkZXJzOiB7XG4gICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb247IGNoYXJzZXQ9dXRmLTgnLFxuICAgICAgJ2NhY2hlLWNvbnRyb2wnOiAnbm8tc3RvcmUnXG4gICAgfVxuICB9KTtcbn1cblxuZnVuY3Rpb24gbWFrZVRva2VuRnJvbVN0cmluZyhzZWVkKXtcbiAgY29uc3QgaGFzaCA9IGNyeXB0by5jcmVhdGVIYXNoKCdzaGExJykudXBkYXRlKHNlZWQpLmRpZ2VzdCgnaGV4Jyk7XG4gIGNvbnN0IHNob3J0ID0gaGFzaC5zbGljZSgwLCAxMik7IC8vIDEyIGhleCBjaGFyc1xuICByZXR1cm4gYCR7c2hvcnQuc2xpY2UoMCwgOCl9LSR7c2hvcnQuc2xpY2UoOCl9YDtcbn1cblxuZnVuY3Rpb24gYmFzZTY0dXJsKGJ5dGVzKXtcbiAgcmV0dXJuIEJ1ZmZlci5mcm9tKGJ5dGVzKS50b1N0cmluZygnYmFzZTY0dXJsJyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZVRva2VuRm9yT3JkZXIob3JkZXJDb2RlLCBpbmRleCwgaW5pdCl7XG4gIGNvbnN0IHRva2VuID0gbWFrZVRva2VuRnJvbVN0cmluZyhgJHtvcmRlckNvZGV9OiR7aW5kZXh9OiR7aW5pdC5wcm9kdWN0X2lkfWApO1xuXG4gIC8vIElmIGl0IGFscmVhZHkgZXhpc3RzLCBrZWVwIGl0IChpZGVtcG90ZW50KVxuICBjb25zdCBleGlzdGluZyA9IGF3YWl0IGdldFRva2VuUmVjb3JkKHRva2VuKTtcbiAgaWYgKGV4aXN0aW5nKSB7XG4gICAgcmV0dXJuIHsgdG9rZW4sIHNldHVwX2tleTogZXhpc3Rpbmcuc2V0dXBfa2V5LCBwcm9kdWN0X2lkOiBleGlzdGluZy5wcm9kdWN0X2lkIH07XG4gIH1cblxuICBjb25zdCBzZXR1cF9rZXkgPSBiYXNlNjR1cmwoY3J5cHRvLnJhbmRvbUJ5dGVzKDE2KSk7XG4gIGNvbnN0IGNhcmQgPSB7XG4gICAgdmVyc2lvbjogMSxcbiAgICB0b2tlbixcbiAgICBwcm9kdWN0X2lkOiBpbml0LnByb2R1Y3RfaWQsXG4gICAgdGhlbWVfaWQ6IGluaXQudGhlbWVfaWQgfHwgJ2RlZmF1bHQnLFxuICAgIGZpZWxkczogaW5pdC5maWVsZHMgfHwge30sXG4gICAgc2V0dXBfa2V5LFxuICAgIGNyZWF0ZWRfYXQ6IERhdGUubm93KCksXG4gICAgY29uZmlndXJlZDogZmFsc2UsXG4gICAgb3V0Y29tZV9tb2RlOiAnd2VfcGljaydcbiAgfTtcblxuICBhd2FpdCBzZXRUb2tlblJlY29yZCh0b2tlbiwgY2FyZCk7XG4gIHJldHVybiB7IHRva2VuLCBzZXR1cF9rZXksIHByb2R1Y3RfaWQ6IGluaXQucHJvZHVjdF9pZCB9O1xufVxuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBoYW5kbGVyKHJlcXVlc3Qpe1xuICBpZiAocmVxdWVzdC5tZXRob2QgIT09ICdQT1NUJykge1xuICAgIHJldHVybiBqc29uKDQwNSwgeyBvazogZmFsc2UsIGVycm9yOiAnTWV0aG9kIG5vdCBhbGxvd2VkJyB9KTtcbiAgfVxuXG4gIGxldCBib2R5O1xuICB0cnkge1xuICAgIGJvZHkgPSBhd2FpdCByZXF1ZXN0Lmpzb24oKTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGpzb24oNDAwLCB7IG9rOiBmYWxzZSwgZXJyb3I6ICdJbnZhbGlkIEpTT04nIH0pO1xuICB9XG5cbiAgY29uc3QgY29kZSA9IChib2R5Py5jb2RlIHx8ICcnKS50b1N0cmluZygpLnRyaW0oKTtcbiAgY29uc3QgaW5pdCA9IGJvZHk/LmluaXQ7XG5cbiAgaWYgKCFjb2RlKSByZXR1cm4ganNvbig0MDAsIHsgb2s6IGZhbHNlLCBlcnJvcjogJ01pc3NpbmcgY29kZScgfSk7XG4gIGlmICghaW5pdCB8fCB0eXBlb2YgaW5pdCAhPT0gJ29iamVjdCcgfHwgIWluaXQucHJvZHVjdF9pZCkge1xuICAgIHJldHVybiBqc29uKDQwMCwgeyBvazogZmFsc2UsIGVycm9yOiAnTWlzc2luZyBpbml0JyB9KTtcbiAgfVxuXG4gIGNvbnN0IHJlcXVlc3RlZEluaXRzID0gW2luaXRdO1xuXG4gIC8vIElkZW1wb3RlbnQgb3JkZXI6IGlmIGFscmVhZHkgZXhpc3RzLCByZXR1cm4gZXhpc3RpbmcgY2FyZHMuXG4gIGNvbnN0IGV4aXN0aW5nT3JkZXIgPSBhd2FpdCBnZXRPcmRlclJlY29yZChjb2RlKTtcbiAgaWYgKGV4aXN0aW5nT3JkZXI/LmNhcmRzPy5sZW5ndGgpIHtcbiAgICByZXR1cm4ganNvbigyMDAsIHsgb2s6IHRydWUsIGV4aXN0aW5nOiB0cnVlLCBjYXJkczogZXhpc3RpbmdPcmRlci5jYXJkcyB9KTtcbiAgfVxuXG4gIGNvbnN0IGNhcmRzID0gW107XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgcmVxdWVzdGVkSW5pdHMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjID0gYXdhaXQgZW5zdXJlVG9rZW5Gb3JPcmRlcihjb2RlLCBpICsgMSwgcmVxdWVzdGVkSW5pdHNbaV0pO1xuICAgIGNhcmRzLnB1c2goYyk7XG4gIH1cblxuICBhd2FpdCBzZXRPcmRlclJlY29yZChjb2RlLCB7IGNvZGUsIGNyZWF0ZWRfYXQ6IERhdGUubm93KCksIGNhcmRzIH0pO1xuXG4gIHJldHVybiBqc29uKDIwMCwgeyBvazogdHJ1ZSwgZXhpc3Rpbmc6IGZhbHNlLCBjYXJkcyB9KTtcbn1cbiIsICJpbXBvcnQgeyBnZXRTdG9yZSB9IGZyb20gJ0BuZXRsaWZ5L2Jsb2JzJztcblxuLy8gQSB0aW55IHdyYXBwZXIgYXJvdW5kIE5ldGxpZnkgQmxvYnMgd2l0aCBhbiBpbi1tZW1vcnkgZmFsbGJhY2suXG4vLyBUaGUgZmFsbGJhY2sgaXMgb25seSBmb3IgbG9jYWwgZGV2IGVtZXJnZW5jaWVzOyBpdCBpcyBOT1QgZHVyYWJsZS5cblxuY29uc3QgbWVtID0ge1xuICB0b2tlbnM6IG5ldyBNYXAoKSxcbiAgb3JkZXJzOiBuZXcgTWFwKClcbn07XG5cbmZ1bmN0aW9uIHRyeUJsb2JTdG9yZXMoKXtcbiAgdHJ5IHtcbiAgICByZXR1cm4ge1xuICAgICAgdG9rZW5zOiBnZXRTdG9yZSh7IG5hbWU6ICdjaGljY2FudG9fdG9rZW5zJywgY29uc2lzdGVuY3k6ICdzdHJvbmcnIH0pLFxuICAgICAgb3JkZXJzOiBnZXRTdG9yZSh7IG5hbWU6ICdjaGljY2FudG9fb3JkZXJzJywgY29uc2lzdGVuY3k6ICdzdHJvbmcnIH0pXG4gICAgfTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmxldCBfc3RvcmVzID0gbnVsbDtcblxuZnVuY3Rpb24gc3RvcmVzKCl7XG4gIGlmIChfc3RvcmVzKSByZXR1cm4gX3N0b3JlcztcbiAgY29uc3QgYmxvYiA9IHRyeUJsb2JTdG9yZXMoKTtcbiAgX3N0b3JlcyA9IGJsb2IgPz8ge1xuICAgIHRva2Vuczoge1xuICAgICAgYXN5bmMgZ2V0KGtleSl7IHJldHVybiBtZW0udG9rZW5zLmhhcyhrZXkpID8gbWVtLnRva2Vucy5nZXQoa2V5KSA6IG51bGw7IH0sXG4gICAgICBhc3luYyBzZXQoa2V5LCB2YWx1ZSl7IG1lbS50b2tlbnMuc2V0KGtleSwgdmFsdWUpOyB9LFxuICAgICAgYXN5bmMgZGVsZXRlKGtleSl7IG1lbS50b2tlbnMuZGVsZXRlKGtleSk7IH1cbiAgICB9LFxuICAgIG9yZGVyczoge1xuICAgICAgYXN5bmMgZ2V0KGtleSl7IHJldHVybiBtZW0ub3JkZXJzLmhhcyhrZXkpID8gbWVtLm9yZGVycy5nZXQoa2V5KSA6IG51bGw7IH0sXG4gICAgICBhc3luYyBzZXQoa2V5LCB2YWx1ZSl7IG1lbS5vcmRlcnMuc2V0KGtleSwgdmFsdWUpOyB9LFxuICAgICAgYXN5bmMgZGVsZXRlKGtleSl7IG1lbS5vcmRlcnMuZGVsZXRlKGtleSk7IH1cbiAgICB9XG4gIH07XG4gIHJldHVybiBfc3RvcmVzO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VG9rZW5SZWNvcmQodG9rZW4pe1xuICBjb25zdCB7IHRva2VucyB9ID0gc3RvcmVzKCk7XG4gIGNvbnN0IHZhbHVlID0gYXdhaXQgdG9rZW5zLmdldCh0b2tlbik7XG4gIGlmICghdmFsdWUpIHJldHVybiBudWxsO1xuICB0cnkgeyByZXR1cm4gSlNPTi5wYXJzZSh2YWx1ZSk7IH0gY2F0Y2ggeyByZXR1cm4gbnVsbDsgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0VG9rZW5SZWNvcmQodG9rZW4sIHJlY29yZCl7XG4gIGNvbnN0IHsgdG9rZW5zIH0gPSBzdG9yZXMoKTtcbiAgYXdhaXQgdG9rZW5zLnNldCh0b2tlbiwgSlNPTi5zdHJpbmdpZnkocmVjb3JkKSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRPcmRlclJlY29yZChjb2RlKXtcbiAgY29uc3QgeyBvcmRlcnMgfSA9IHN0b3JlcygpO1xuICBjb25zdCB2YWx1ZSA9IGF3YWl0IG9yZGVycy5nZXQoY29kZSk7XG4gIGlmICghdmFsdWUpIHJldHVybiBudWxsO1xuICB0cnkgeyByZXR1cm4gSlNPTi5wYXJzZSh2YWx1ZSk7IH0gY2F0Y2ggeyByZXR1cm4gbnVsbDsgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0T3JkZXJSZWNvcmQoY29kZSwgcmVjb3JkKXtcbiAgY29uc3QgeyBvcmRlcnMgfSA9IHN0b3JlcygpO1xuICBhd2FpdCBvcmRlcnMuc2V0KGNvZGUsIEpTT04uc3RyaW5naWZ5KHJlY29yZCkpO1xufVxuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7OztBQUFBLE9BQU8sWUFBWTs7O0FDQW5CLFNBQVMsZ0JBQWdCO0FBS3pCLElBQU0sTUFBTTtBQUFBLEVBQ1YsUUFBUSxvQkFBSSxJQUFJO0FBQUEsRUFDaEIsUUFBUSxvQkFBSSxJQUFJO0FBQ2xCO0FBRUEsU0FBUyxnQkFBZTtBQUN0QixNQUFJO0FBQ0YsV0FBTztBQUFBLE1BQ0wsUUFBUSxTQUFTLEVBQUUsTUFBTSxvQkFBb0IsYUFBYSxTQUFTLENBQUM7QUFBQSxNQUNwRSxRQUFRLFNBQVMsRUFBRSxNQUFNLG9CQUFvQixhQUFhLFNBQVMsQ0FBQztBQUFBLElBQ3RFO0FBQUEsRUFDRixTQUFTLEdBQUc7QUFDVixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsSUFBSSxVQUFVO0FBRWQsU0FBUyxTQUFRO0FBQ2YsTUFBSSxRQUFTLFFBQU87QUFDcEIsUUFBTSxPQUFPLGNBQWM7QUFDM0IsWUFBVSxRQUFRO0FBQUEsSUFDaEIsUUFBUTtBQUFBLE1BQ04sTUFBTSxJQUFJLEtBQUk7QUFBRSxlQUFPLElBQUksT0FBTyxJQUFJLEdBQUcsSUFBSSxJQUFJLE9BQU8sSUFBSSxHQUFHLElBQUk7QUFBQSxNQUFNO0FBQUEsTUFDekUsTUFBTSxJQUFJLEtBQUssT0FBTTtBQUFFLFlBQUksT0FBTyxJQUFJLEtBQUssS0FBSztBQUFBLE1BQUc7QUFBQSxNQUNuRCxNQUFNLE9BQU8sS0FBSTtBQUFFLFlBQUksT0FBTyxPQUFPLEdBQUc7QUFBQSxNQUFHO0FBQUEsSUFDN0M7QUFBQSxJQUNBLFFBQVE7QUFBQSxNQUNOLE1BQU0sSUFBSSxLQUFJO0FBQUUsZUFBTyxJQUFJLE9BQU8sSUFBSSxHQUFHLElBQUksSUFBSSxPQUFPLElBQUksR0FBRyxJQUFJO0FBQUEsTUFBTTtBQUFBLE1BQ3pFLE1BQU0sSUFBSSxLQUFLLE9BQU07QUFBRSxZQUFJLE9BQU8sSUFBSSxLQUFLLEtBQUs7QUFBQSxNQUFHO0FBQUEsTUFDbkQsTUFBTSxPQUFPLEtBQUk7QUFBRSxZQUFJLE9BQU8sT0FBTyxHQUFHO0FBQUEsTUFBRztBQUFBLElBQzdDO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUVBLGVBQXNCLGVBQWUsT0FBTTtBQUN6QyxRQUFNLEVBQUUsT0FBTyxJQUFJLE9BQU87QUFDMUIsUUFBTSxRQUFRLE1BQU0sT0FBTyxJQUFJLEtBQUs7QUFDcEMsTUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixNQUFJO0FBQUUsV0FBTyxLQUFLLE1BQU0sS0FBSztBQUFBLEVBQUcsUUFBUTtBQUFFLFdBQU87QUFBQSxFQUFNO0FBQ3pEO0FBRUEsZUFBc0IsZUFBZSxPQUFPLFFBQU87QUFDakQsUUFBTSxFQUFFLE9BQU8sSUFBSSxPQUFPO0FBQzFCLFFBQU0sT0FBTyxJQUFJLE9BQU8sS0FBSyxVQUFVLE1BQU0sQ0FBQztBQUNoRDtBQUVBLGVBQXNCLGVBQWUsTUFBSztBQUN4QyxRQUFNLEVBQUUsT0FBTyxJQUFJLE9BQU87QUFDMUIsUUFBTSxRQUFRLE1BQU0sT0FBTyxJQUFJLElBQUk7QUFDbkMsTUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixNQUFJO0FBQUUsV0FBTyxLQUFLLE1BQU0sS0FBSztBQUFBLEVBQUcsUUFBUTtBQUFFLFdBQU87QUFBQSxFQUFNO0FBQ3pEO0FBRUEsZUFBc0IsZUFBZSxNQUFNLFFBQU87QUFDaEQsUUFBTSxFQUFFLE9BQU8sSUFBSSxPQUFPO0FBQzFCLFFBQU0sT0FBTyxJQUFJLE1BQU0sS0FBSyxVQUFVLE1BQU0sQ0FBQztBQUMvQzs7O0FENURBLFNBQVMsS0FBSyxRQUFRLEtBQUk7QUFDeEIsU0FBTyxJQUFJLFNBQVMsS0FBSyxVQUFVLEdBQUcsR0FBRztBQUFBLElBQ3ZDO0FBQUEsSUFDQSxTQUFTO0FBQUEsTUFDUCxnQkFBZ0I7QUFBQSxNQUNoQixpQkFBaUI7QUFBQSxJQUNuQjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBRUEsU0FBUyxvQkFBb0IsTUFBSztBQUNoQyxRQUFNLE9BQU8sT0FBTyxXQUFXLE1BQU0sRUFBRSxPQUFPLElBQUksRUFBRSxPQUFPLEtBQUs7QUFDaEUsUUFBTSxRQUFRLEtBQUssTUFBTSxHQUFHLEVBQUU7QUFDOUIsU0FBTyxHQUFHLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFJLE1BQU0sTUFBTSxDQUFDLENBQUM7QUFDL0M7QUFFQSxTQUFTLFVBQVUsT0FBTTtBQUN2QixTQUFPLE9BQU8sS0FBSyxLQUFLLEVBQUUsU0FBUyxXQUFXO0FBQ2hEO0FBRUEsZUFBZSxvQkFBb0IsV0FBVyxPQUFPLE1BQUs7QUFDeEQsUUFBTSxRQUFRLG9CQUFvQixHQUFHLFNBQVMsSUFBSSxLQUFLLElBQUksS0FBSyxVQUFVLEVBQUU7QUFHNUUsUUFBTSxXQUFXLE1BQU0sZUFBZSxLQUFLO0FBQzNDLE1BQUksVUFBVTtBQUNaLFdBQU8sRUFBRSxPQUFPLFdBQVcsU0FBUyxXQUFXLFlBQVksU0FBUyxXQUFXO0FBQUEsRUFDakY7QUFFQSxRQUFNLFlBQVksVUFBVSxPQUFPLFlBQVksRUFBRSxDQUFDO0FBQ2xELFFBQU0sT0FBTztBQUFBLElBQ1gsU0FBUztBQUFBLElBQ1Q7QUFBQSxJQUNBLFlBQVksS0FBSztBQUFBLElBQ2pCLFVBQVUsS0FBSyxZQUFZO0FBQUEsSUFDM0IsUUFBUSxLQUFLLFVBQVUsQ0FBQztBQUFBLElBQ3hCO0FBQUEsSUFDQSxZQUFZLEtBQUssSUFBSTtBQUFBLElBQ3JCLFlBQVk7QUFBQSxJQUNaLGNBQWM7QUFBQSxFQUNoQjtBQUVBLFFBQU0sZUFBZSxPQUFPLElBQUk7QUFDaEMsU0FBTyxFQUFFLE9BQU8sV0FBVyxZQUFZLEtBQUssV0FBVztBQUN6RDtBQUVBLGVBQU8sUUFBK0IsU0FBUTtBQUM1QyxNQUFJLFFBQVEsV0FBVyxRQUFRO0FBQzdCLFdBQU8sS0FBSyxLQUFLLEVBQUUsSUFBSSxPQUFPLE9BQU8scUJBQXFCLENBQUM7QUFBQSxFQUM3RDtBQUVBLE1BQUk7QUFDSixNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSztBQUFBLEVBQzVCLFFBQVE7QUFDTixXQUFPLEtBQUssS0FBSyxFQUFFLElBQUksT0FBTyxPQUFPLGVBQWUsQ0FBQztBQUFBLEVBQ3ZEO0FBRUEsUUFBTSxRQUFRLE1BQU0sUUFBUSxJQUFJLFNBQVMsRUFBRSxLQUFLO0FBQ2hELFFBQU0sT0FBTyxNQUFNO0FBRW5CLE1BQUksQ0FBQyxLQUFNLFFBQU8sS0FBSyxLQUFLLEVBQUUsSUFBSSxPQUFPLE9BQU8sZUFBZSxDQUFDO0FBQ2hFLE1BQUksQ0FBQyxRQUFRLE9BQU8sU0FBUyxZQUFZLENBQUMsS0FBSyxZQUFZO0FBQ3pELFdBQU8sS0FBSyxLQUFLLEVBQUUsSUFBSSxPQUFPLE9BQU8sZUFBZSxDQUFDO0FBQUEsRUFDdkQ7QUFFQSxRQUFNLGlCQUFpQixDQUFDLElBQUk7QUFHNUIsUUFBTSxnQkFBZ0IsTUFBTSxlQUFlLElBQUk7QUFDL0MsTUFBSSxlQUFlLE9BQU8sUUFBUTtBQUNoQyxXQUFPLEtBQUssS0FBSyxFQUFFLElBQUksTUFBTSxVQUFVLE1BQU0sT0FBTyxjQUFjLE1BQU0sQ0FBQztBQUFBLEVBQzNFO0FBRUEsUUFBTSxRQUFRLENBQUM7QUFDZixXQUFTLElBQUksR0FBRyxJQUFJLGVBQWUsUUFBUSxLQUFLO0FBQzlDLFVBQU0sSUFBSSxNQUFNLG9CQUFvQixNQUFNLElBQUksR0FBRyxlQUFlLENBQUMsQ0FBQztBQUNsRSxVQUFNLEtBQUssQ0FBQztBQUFBLEVBQ2Q7QUFFQSxRQUFNLGVBQWUsTUFBTSxFQUFFLE1BQU0sWUFBWSxLQUFLLElBQUksR0FBRyxNQUFNLENBQUM7QUFFbEUsU0FBTyxLQUFLLEtBQUssRUFBRSxJQUFJLE1BQU0sVUFBVSxPQUFPLE1BQU0sQ0FBQztBQUN2RDsiLAogICJuYW1lcyI6IFtdCn0K
