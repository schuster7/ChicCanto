
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_db.js
import { getStore } from "@netlify/blobs";
var mem = {
  tokens: /* @__PURE__ */ new Map(),
  orders: /* @__PURE__ */ new Map()
};
function tryBlobStores() {
  try {
    return {
      tokens: getStore({ name: "chiccanto_tokens", consistency: "strong" }),
      orders: getStore({ name: "chiccanto_orders", consistency: "strong" })
    };
  } catch (e) {
    return null;
  }
}
var _stores = null;
function stores() {
  if (_stores) return _stores;
  const blob = tryBlobStores();
  _stores = blob ?? {
    tokens: {
      async get(key) {
        return mem.tokens.has(key) ? mem.tokens.get(key) : null;
      },
      async set(key, value) {
        mem.tokens.set(key, value);
      },
      async delete(key) {
        mem.tokens.delete(key);
      }
    },
    orders: {
      async get(key) {
        return mem.orders.has(key) ? mem.orders.get(key) : null;
      },
      async set(key, value) {
        mem.orders.set(key, value);
      },
      async delete(key) {
        mem.orders.delete(key);
      }
    }
  };
  return _stores;
}
async function getTokenRecord(token) {
  const { tokens } = stores();
  const value = await tokens.get(token);
  if (!value) return null;
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}
async function setTokenRecord(token, record) {
  const { tokens } = stores();
  await tokens.set(token, JSON.stringify(record));
}

// netlify/functions/token.js
function json(status, obj) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store"
    }
  });
}
function extractTokenFromPath(urlStr) {
  const url = new URL(urlStr);
  const parts = url.pathname.split("/").filter(Boolean);
  const idx = parts.lastIndexOf("token");
  if (idx === -1 || idx >= parts.length - 1) return null;
  return decodeURIComponent(parts[idx + 1]);
}
async function handler(request) {
  const token = extractTokenFromPath(request.url);
  if (!token) return json(400, { ok: false, error: "Missing token" });
  if (request.method === "GET") {
    const record = await getTokenRecord(token);
    if (!record) return json(404, { ok: false, error: "Token not found" });
    return json(200, record);
  }
  if (request.method === "PUT") {
    let body;
    try {
      body = await request.json();
    } catch {
      return json(400, { ok: false, error: "Invalid JSON" });
    }
    if (!body || typeof body !== "object") {
      return json(400, { ok: false, error: "Invalid body" });
    }
    body.token = token;
    await setTokenRecord(token, body);
    return json(200, body);
  }
  return json(405, { ok: false, error: "Method not allowed" });
}
export {
  handler as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibmV0bGlmeS9mdW5jdGlvbnMvX2RiLmpzIiwgIm5ldGxpZnkvZnVuY3Rpb25zL3Rva2VuLmpzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgeyBnZXRTdG9yZSB9IGZyb20gJ0BuZXRsaWZ5L2Jsb2JzJztcblxuLy8gQSB0aW55IHdyYXBwZXIgYXJvdW5kIE5ldGxpZnkgQmxvYnMgd2l0aCBhbiBpbi1tZW1vcnkgZmFsbGJhY2suXG4vLyBUaGUgZmFsbGJhY2sgaXMgb25seSBmb3IgbG9jYWwgZGV2IGVtZXJnZW5jaWVzOyBpdCBpcyBOT1QgZHVyYWJsZS5cblxuY29uc3QgbWVtID0ge1xuICB0b2tlbnM6IG5ldyBNYXAoKSxcbiAgb3JkZXJzOiBuZXcgTWFwKClcbn07XG5cbmZ1bmN0aW9uIHRyeUJsb2JTdG9yZXMoKXtcbiAgdHJ5IHtcbiAgICByZXR1cm4ge1xuICAgICAgdG9rZW5zOiBnZXRTdG9yZSh7IG5hbWU6ICdjaGljY2FudG9fdG9rZW5zJywgY29uc2lzdGVuY3k6ICdzdHJvbmcnIH0pLFxuICAgICAgb3JkZXJzOiBnZXRTdG9yZSh7IG5hbWU6ICdjaGljY2FudG9fb3JkZXJzJywgY29uc2lzdGVuY3k6ICdzdHJvbmcnIH0pXG4gICAgfTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmxldCBfc3RvcmVzID0gbnVsbDtcblxuZnVuY3Rpb24gc3RvcmVzKCl7XG4gIGlmIChfc3RvcmVzKSByZXR1cm4gX3N0b3JlcztcbiAgY29uc3QgYmxvYiA9IHRyeUJsb2JTdG9yZXMoKTtcbiAgX3N0b3JlcyA9IGJsb2IgPz8ge1xuICAgIHRva2Vuczoge1xuICAgICAgYXN5bmMgZ2V0KGtleSl7IHJldHVybiBtZW0udG9rZW5zLmhhcyhrZXkpID8gbWVtLnRva2Vucy5nZXQoa2V5KSA6IG51bGw7IH0sXG4gICAgICBhc3luYyBzZXQoa2V5LCB2YWx1ZSl7IG1lbS50b2tlbnMuc2V0KGtleSwgdmFsdWUpOyB9LFxuICAgICAgYXN5bmMgZGVsZXRlKGtleSl7IG1lbS50b2tlbnMuZGVsZXRlKGtleSk7IH1cbiAgICB9LFxuICAgIG9yZGVyczoge1xuICAgICAgYXN5bmMgZ2V0KGtleSl7IHJldHVybiBtZW0ub3JkZXJzLmhhcyhrZXkpID8gbWVtLm9yZGVycy5nZXQoa2V5KSA6IG51bGw7IH0sXG4gICAgICBhc3luYyBzZXQoa2V5LCB2YWx1ZSl7IG1lbS5vcmRlcnMuc2V0KGtleSwgdmFsdWUpOyB9LFxuICAgICAgYXN5bmMgZGVsZXRlKGtleSl7IG1lbS5vcmRlcnMuZGVsZXRlKGtleSk7IH1cbiAgICB9XG4gIH07XG4gIHJldHVybiBfc3RvcmVzO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VG9rZW5SZWNvcmQodG9rZW4pe1xuICBjb25zdCB7IHRva2VucyB9ID0gc3RvcmVzKCk7XG4gIGNvbnN0IHZhbHVlID0gYXdhaXQgdG9rZW5zLmdldCh0b2tlbik7XG4gIGlmICghdmFsdWUpIHJldHVybiBudWxsO1xuICB0cnkgeyByZXR1cm4gSlNPTi5wYXJzZSh2YWx1ZSk7IH0gY2F0Y2ggeyByZXR1cm4gbnVsbDsgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0VG9rZW5SZWNvcmQodG9rZW4sIHJlY29yZCl7XG4gIGNvbnN0IHsgdG9rZW5zIH0gPSBzdG9yZXMoKTtcbiAgYXdhaXQgdG9rZW5zLnNldCh0b2tlbiwgSlNPTi5zdHJpbmdpZnkocmVjb3JkKSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRPcmRlclJlY29yZChjb2RlKXtcbiAgY29uc3QgeyBvcmRlcnMgfSA9IHN0b3JlcygpO1xuICBjb25zdCB2YWx1ZSA9IGF3YWl0IG9yZGVycy5nZXQoY29kZSk7XG4gIGlmICghdmFsdWUpIHJldHVybiBudWxsO1xuICB0cnkgeyByZXR1cm4gSlNPTi5wYXJzZSh2YWx1ZSk7IH0gY2F0Y2ggeyByZXR1cm4gbnVsbDsgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0T3JkZXJSZWNvcmQoY29kZSwgcmVjb3JkKXtcbiAgY29uc3QgeyBvcmRlcnMgfSA9IHN0b3JlcygpO1xuICBhd2FpdCBvcmRlcnMuc2V0KGNvZGUsIEpTT04uc3RyaW5naWZ5KHJlY29yZCkpO1xufVxuIiwgImltcG9ydCB7IGdldFRva2VuUmVjb3JkLCBzZXRUb2tlblJlY29yZCB9IGZyb20gJy4vX2RiLmpzJztcblxuZnVuY3Rpb24ganNvbihzdGF0dXMsIG9iail7XG4gIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkob2JqKSwge1xuICAgIHN0YXR1cyxcbiAgICBoZWFkZXJzOiB7XG4gICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb247IGNoYXJzZXQ9dXRmLTgnLFxuICAgICAgJ2NhY2hlLWNvbnRyb2wnOiAnbm8tc3RvcmUnXG4gICAgfVxuICB9KTtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdFRva2VuRnJvbVBhdGgodXJsU3RyKXtcbiAgY29uc3QgdXJsID0gbmV3IFVSTCh1cmxTdHIpO1xuICBjb25zdCBwYXJ0cyA9IHVybC5wYXRobmFtZS5zcGxpdCgnLycpLmZpbHRlcihCb29sZWFuKTtcbiAgY29uc3QgaWR4ID0gcGFydHMubGFzdEluZGV4T2YoJ3Rva2VuJyk7XG4gIGlmIChpZHggPT09IC0xIHx8IGlkeCA+PSBwYXJ0cy5sZW5ndGggLSAxKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIGRlY29kZVVSSUNvbXBvbmVudChwYXJ0c1tpZHggKyAxXSk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZXIocmVxdWVzdCl7XG4gIGNvbnN0IHRva2VuID0gZXh0cmFjdFRva2VuRnJvbVBhdGgocmVxdWVzdC51cmwpO1xuICBpZiAoIXRva2VuKSByZXR1cm4ganNvbig0MDAsIHsgb2s6IGZhbHNlLCBlcnJvcjogJ01pc3NpbmcgdG9rZW4nIH0pO1xuXG4gIGlmIChyZXF1ZXN0Lm1ldGhvZCA9PT0gJ0dFVCcpe1xuICAgIGNvbnN0IHJlY29yZCA9IGF3YWl0IGdldFRva2VuUmVjb3JkKHRva2VuKTtcbiAgICBpZiAoIXJlY29yZCkgcmV0dXJuIGpzb24oNDA0LCB7IG9rOiBmYWxzZSwgZXJyb3I6ICdUb2tlbiBub3QgZm91bmQnIH0pO1xuICAgIC8vIElNUE9SVEFOVDogRnJvbnRlbmQgZXhwZWN0cyB0aGUgY2FyZCByZWNvcmQgYXQgdGhlIHRvcC1sZXZlbCAoc2FtZSBhcyBkZXYtYXBpLmNqcykuXG4gICAgLy8gUmV0dXJuaW5nIGEgd3JhcHBlciBsaWtlIHsgb2s6IHRydWUsIGNhcmQ6IHsuLi59IH0gYnJlYWtzIHN0b3JlLmpzIChjYXJkLnNldHVwX2tleSBiZWNvbWVzIHVuZGVmaW5lZCkuXG4gICAgcmV0dXJuIGpzb24oMjAwLCByZWNvcmQpO1xuICB9XG5cbiAgaWYgKHJlcXVlc3QubWV0aG9kID09PSAnUFVUJyl7XG4gICAgbGV0IGJvZHk7XG4gICAgdHJ5IHtcbiAgICAgIGJvZHkgPSBhd2FpdCByZXF1ZXN0Lmpzb24oKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHJldHVybiBqc29uKDQwMCwgeyBvazogZmFsc2UsIGVycm9yOiAnSW52YWxpZCBKU09OJyB9KTtcbiAgICB9XG5cbiAgICBpZiAoIWJvZHkgfHwgdHlwZW9mIGJvZHkgIT09ICdvYmplY3QnKXtcbiAgICAgIHJldHVybiBqc29uKDQwMCwgeyBvazogZmFsc2UsIGVycm9yOiAnSW52YWxpZCBib2R5JyB9KTtcbiAgICB9XG5cbiAgICAvLyBGb3JjZSBwYXRoIHRva2VuIHRvIGJlIHNvdXJjZSBvZiB0cnV0aFxuICAgIGJvZHkudG9rZW4gPSB0b2tlbjtcblxuICAgIGF3YWl0IHNldFRva2VuUmVjb3JkKHRva2VuLCBib2R5KTtcbiAgICAvLyBSZXR1cm4gdGhlIHN0b3JlZCByZWNvcmQgKHNhbWUgc2hhcGUgYXMgR0VUKSBzbyB0aGUgZnJvbnRlbmQgZG9lc24ndCBjbG9iYmVyIHN0YXRlLlxuICAgIHJldHVybiBqc29uKDIwMCwgYm9keSk7XG4gIH1cblxuICByZXR1cm4ganNvbig0MDUsIHsgb2s6IGZhbHNlLCBlcnJvcjogJ01ldGhvZCBub3QgYWxsb3dlZCcgfSk7XG59XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7O0FBQUEsU0FBUyxnQkFBZ0I7QUFLekIsSUFBTSxNQUFNO0FBQUEsRUFDVixRQUFRLG9CQUFJLElBQUk7QUFBQSxFQUNoQixRQUFRLG9CQUFJLElBQUk7QUFDbEI7QUFFQSxTQUFTLGdCQUFlO0FBQ3RCLE1BQUk7QUFDRixXQUFPO0FBQUEsTUFDTCxRQUFRLFNBQVMsRUFBRSxNQUFNLG9CQUFvQixhQUFhLFNBQVMsQ0FBQztBQUFBLE1BQ3BFLFFBQVEsU0FBUyxFQUFFLE1BQU0sb0JBQW9CLGFBQWEsU0FBUyxDQUFDO0FBQUEsSUFDdEU7QUFBQSxFQUNGLFNBQVMsR0FBRztBQUNWLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxJQUFJLFVBQVU7QUFFZCxTQUFTLFNBQVE7QUFDZixNQUFJLFFBQVMsUUFBTztBQUNwQixRQUFNLE9BQU8sY0FBYztBQUMzQixZQUFVLFFBQVE7QUFBQSxJQUNoQixRQUFRO0FBQUEsTUFDTixNQUFNLElBQUksS0FBSTtBQUFFLGVBQU8sSUFBSSxPQUFPLElBQUksR0FBRyxJQUFJLElBQUksT0FBTyxJQUFJLEdBQUcsSUFBSTtBQUFBLE1BQU07QUFBQSxNQUN6RSxNQUFNLElBQUksS0FBSyxPQUFNO0FBQUUsWUFBSSxPQUFPLElBQUksS0FBSyxLQUFLO0FBQUEsTUFBRztBQUFBLE1BQ25ELE1BQU0sT0FBTyxLQUFJO0FBQUUsWUFBSSxPQUFPLE9BQU8sR0FBRztBQUFBLE1BQUc7QUFBQSxJQUM3QztBQUFBLElBQ0EsUUFBUTtBQUFBLE1BQ04sTUFBTSxJQUFJLEtBQUk7QUFBRSxlQUFPLElBQUksT0FBTyxJQUFJLEdBQUcsSUFBSSxJQUFJLE9BQU8sSUFBSSxHQUFHLElBQUk7QUFBQSxNQUFNO0FBQUEsTUFDekUsTUFBTSxJQUFJLEtBQUssT0FBTTtBQUFFLFlBQUksT0FBTyxJQUFJLEtBQUssS0FBSztBQUFBLE1BQUc7QUFBQSxNQUNuRCxNQUFNLE9BQU8sS0FBSTtBQUFFLFlBQUksT0FBTyxPQUFPLEdBQUc7QUFBQSxNQUFHO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBRUEsZUFBc0IsZUFBZSxPQUFNO0FBQ3pDLFFBQU0sRUFBRSxPQUFPLElBQUksT0FBTztBQUMxQixRQUFNLFFBQVEsTUFBTSxPQUFPLElBQUksS0FBSztBQUNwQyxNQUFJLENBQUMsTUFBTyxRQUFPO0FBQ25CLE1BQUk7QUFBRSxXQUFPLEtBQUssTUFBTSxLQUFLO0FBQUEsRUFBRyxRQUFRO0FBQUUsV0FBTztBQUFBLEVBQU07QUFDekQ7QUFFQSxlQUFzQixlQUFlLE9BQU8sUUFBTztBQUNqRCxRQUFNLEVBQUUsT0FBTyxJQUFJLE9BQU87QUFDMUIsUUFBTSxPQUFPLElBQUksT0FBTyxLQUFLLFVBQVUsTUFBTSxDQUFDO0FBQ2hEOzs7QUNqREEsU0FBUyxLQUFLLFFBQVEsS0FBSTtBQUN4QixTQUFPLElBQUksU0FBUyxLQUFLLFVBQVUsR0FBRyxHQUFHO0FBQUEsSUFDdkM7QUFBQSxJQUNBLFNBQVM7QUFBQSxNQUNQLGdCQUFnQjtBQUFBLE1BQ2hCLGlCQUFpQjtBQUFBLElBQ25CO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFFQSxTQUFTLHFCQUFxQixRQUFPO0FBQ25DLFFBQU0sTUFBTSxJQUFJLElBQUksTUFBTTtBQUMxQixRQUFNLFFBQVEsSUFBSSxTQUFTLE1BQU0sR0FBRyxFQUFFLE9BQU8sT0FBTztBQUNwRCxRQUFNLE1BQU0sTUFBTSxZQUFZLE9BQU87QUFDckMsTUFBSSxRQUFRLE1BQU0sT0FBTyxNQUFNLFNBQVMsRUFBRyxRQUFPO0FBQ2xELFNBQU8sbUJBQW1CLE1BQU0sTUFBTSxDQUFDLENBQUM7QUFDMUM7QUFFQSxlQUFPLFFBQStCLFNBQVE7QUFDNUMsUUFBTSxRQUFRLHFCQUFxQixRQUFRLEdBQUc7QUFDOUMsTUFBSSxDQUFDLE1BQU8sUUFBTyxLQUFLLEtBQUssRUFBRSxJQUFJLE9BQU8sT0FBTyxnQkFBZ0IsQ0FBQztBQUVsRSxNQUFJLFFBQVEsV0FBVyxPQUFNO0FBQzNCLFVBQU0sU0FBUyxNQUFNLGVBQWUsS0FBSztBQUN6QyxRQUFJLENBQUMsT0FBUSxRQUFPLEtBQUssS0FBSyxFQUFFLElBQUksT0FBTyxPQUFPLGtCQUFrQixDQUFDO0FBR3JFLFdBQU8sS0FBSyxLQUFLLE1BQU07QUFBQSxFQUN6QjtBQUVBLE1BQUksUUFBUSxXQUFXLE9BQU07QUFDM0IsUUFBSTtBQUNKLFFBQUk7QUFDRixhQUFPLE1BQU0sUUFBUSxLQUFLO0FBQUEsSUFDNUIsUUFBUTtBQUNOLGFBQU8sS0FBSyxLQUFLLEVBQUUsSUFBSSxPQUFPLE9BQU8sZUFBZSxDQUFDO0FBQUEsSUFDdkQ7QUFFQSxRQUFJLENBQUMsUUFBUSxPQUFPLFNBQVMsVUFBUztBQUNwQyxhQUFPLEtBQUssS0FBSyxFQUFFLElBQUksT0FBTyxPQUFPLGVBQWUsQ0FBQztBQUFBLElBQ3ZEO0FBR0EsU0FBSyxRQUFRO0FBRWIsVUFBTSxlQUFlLE9BQU8sSUFBSTtBQUVoQyxXQUFPLEtBQUssS0FBSyxJQUFJO0FBQUEsRUFDdkI7QUFFQSxTQUFPLEtBQUssS0FBSyxFQUFFLElBQUksT0FBTyxPQUFPLHFCQUFxQixDQUFDO0FBQzdEOyIsCiAgIm5hbWVzIjogW10KfQo=
