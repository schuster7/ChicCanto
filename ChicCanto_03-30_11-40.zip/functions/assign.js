// Cloudflare Pages Function route: POST /assign
// Assigns activation code(s) to an Etsy order, server-side.
// Manual fulfillment v1: user selects card_key + quantity (1 or 4).
// Each activation code is bound to a single card (one redeem = one card).

function json(data, status = 200){
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
    },
  });
}

async function readJson(request){
  const ct = request.headers.get('content-type') || '';
  if (!ct.toLowerCase().includes('application/json')) return null;
  try{ return await request.json(); } catch { return null; }
}

function normalizeOrderId(raw){
  // Keep Etsy order IDs exactly as the fulfiller pasted, but trimmed.
  return String(raw || '').trim();
}

function normalizeCardKey(raw){
  return String(raw || '').trim();
}

function normalizeQuantity(raw){
  const n = parseInt(String(raw ?? '').trim(), 10);
  if (n === 4) return 4;
  return 1;
}

function buildOrderKey(order_id, card_key, quantity){
  return `order:${order_id}:${card_key}:${quantity}`;
}

function buildOrderIndexKey(order_id){
  return `order:${order_id}`;
}

function cardKeyToCodePrefix(card_key){
  // Human-readable prefix for support. Keep it stable once issued.
  const k = String(card_key || '').trim();
  const MAP = {
    'men-novice1': 'CC-MEN-STD1',
    'men-novice-birthday1': 'CC-MEN-BDAY1',
    'women-novice1': 'CC-WOM-STD1',
    'women-novice-birthday1': 'CC-WOM-BDAY1',
    'men-advanced1': 'CC-MEN-ADV1',
    'women-advanced1': 'CC-WOM-ADV1',
  };
  return MAP[k] || 'CC-CARD';
}

function buildMessage({ codes, origin, buyerName }){
  const base = `${origin}/`;
  const faq = `${base}faq/`;

  const name = String(buyerName || '').trim();
  const greeting = name ? `Hi ${name},` : 'Hi,';

  const list = (Array.isArray(codes) ? codes : [])
    .map((c) => String(c || '').trim())
    .filter(Boolean);

  const buildActivationLink = (code) => `${base}?code=${encodeURIComponent(code)}`;

  if (list.length <= 1){
    const assignedCode = list[0] || '';
    const activationLinkWithCode = buildActivationLink(assignedCode);

    return (
`${greeting}

Thanks for your order, and welcome to ChicCanto.

Your activation code: ${assignedCode}

Quick start (recommended):
Open this link and your code will be filled in automatically:

${activationLinkWithCode}

Manual option:
1. Open: ${base}
2. Paste your activation code and follow the steps on screen

This is quick, private, and works on both phone and desktop.

Sharing tip (important):
Use the recipient link you get after setup. It opens an “Open” page first, because scratching does not work inside Messenger or Instagram’s in-app browser. The page will guide them to open it in their browser.

Need the link again later? Just redeem the same code.

Need help?
FAQ: ${faq}

Have fun,
ChicCanto`
    );
  }

  const codeLines = list.map((code, i) => `Card ${i + 1} code: ${code}`);
  const linkLines = list.map((code, i) => `Card ${i + 1}: ${buildActivationLink(code)}`);

  return (
`${greeting}

Thanks for your order, and welcome to ChicCanto.

Your ${list.length} activation codes (one per card):
${codeLines.join('\n')}

Quick start (recommended):
Open a link below and the matching code will be filled in automatically:

${linkLines.join('\n')}

Manual option:
1. Open: ${base}
2. Paste your activation code and follow the steps on screen

This is quick, private, and works on both phone and desktop.

Sharing tip (important):
Use the recipient link you get after setup. It opens an “Open” page first, because scratching does not work inside Messenger or Instagram’s in-app browser. The page will guide them to open it in their browser.

Need the link again later? Just redeem the same code.

Need help?
FAQ: ${faq}

Have fun,
ChicCanto`
  );
}



async function getJsonKV(env, key){
  const raw = await env.CARDS_KV.get(key);
  if (!raw) return null;
  try{ return JSON.parse(raw); } catch { return null; }
}

function isInactiveOrderRecord(rec){
  if (!rec || typeof rec !== 'object') return false;
  const status = String(rec.status || '').toLowerCase();
  return status === 'voided' || status === 'replaced';
}

async function inspectAssignmentState(env, codes){
  const list = Array.isArray(codes) ? codes.map((v) => String(v || '').trim()).filter(Boolean) : [];
  if (!list.length) return { can_void_unactivated: false, assignment_state: 'unknown' };

  const records = [];
  for (const code of list){
    const rec = await getJsonKV(env, `ac:${code}`);
    if (!rec || typeof rec !== 'object'){
      return { can_void_unactivated: false, assignment_state: 'unknown' };
    }
    records.push(rec);
  }

  const allAssignedUnactivated = records.every((rec) => {
    const status = String(rec.status || '').toLowerCase();
    const hasTokens = Array.isArray(rec.tokens) && rec.tokens.length > 0;
    return status === 'assigned' && !hasTokens;
  });

  if (allAssignedUnactivated){
    return { can_void_unactivated: true, assignment_state: 'assigned_unactivated' };
  }

  const anyVoided = records.some((rec) => String(rec.status || '').toLowerCase() === 'voided');
  if (anyVoided){
    return { can_void_unactivated: false, assignment_state: 'voided' };
  }

  const anyReplaced = records.some((rec) => String(rec.status || '').toLowerCase() === 'replaced');
  if (anyReplaced){
    return { can_void_unactivated: false, assignment_state: 'replaced' };
  }

  const anyActivated = records.some((rec) => {
    const status = String(rec.status || '').toLowerCase();
    const hasTokens = Array.isArray(rec.tokens) && rec.tokens.length > 0;
    return hasTokens || status === 'redeemed';
  });

  if (anyActivated){
    return { can_void_unactivated: false, assignment_state: 'activated' };
  }

  return { can_void_unactivated: false, assignment_state: 'unknown' };
}

const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // avoids 0/O and 1/I

function randomChars(len){
  const bytes = new Uint8Array(len);
  crypto.getRandomValues(bytes);
  let out = '';
  for (let i = 0; i < len; i++){
    out += CODE_ALPHABET[bytes[i] % CODE_ALPHABET.length];
  }
  return out;
}

async function generateUniqueCode(env, prefix){
  // PREFIX-XXXXXXXX (8 random chars)
  for (let attempt = 0; attempt < 12; attempt++){
    const code = `${prefix}-${randomChars(8)}`;
    const exists = await env.CARDS_KV.get(`ac:${code}`);
    if (!exists) return code;
  }
  throw new Error('Failed to generate a unique code.');
}

export async function onRequestPost(context){
  const { request, env } = context;

  if (!env || !env.CARDS_KV){
    return json({ ok: false, error: 'Server misconfigured: missing CARDS_KV binding.' }, 500);
  }

  // Auth: require a valid signed session cookie (set by POST /auth).
  const sessionSecret = String(env.FULFILL_SESSION_SECRET || '').trim();
  if (!sessionSecret){
    return json({ ok: false, error: 'Server misconfigured: missing FULFILL_SESSION_SECRET.' }, 500);
  }

  const authed = await verifySessionCookie(request, sessionSecret);
  if (!authed){
    return json({ ok: false, error: 'Unauthorized.' }, 401);
  }

  const body = await readJson(request);
  if (!body){
    return json({ ok: false, error: 'Invalid JSON body.' }, 400);
  }

  const order_id = normalizeOrderId(body.order_id);
  const card_key = normalizeCardKey(body.card_key);
  const quantity = normalizeQuantity(body.quantity);
  const buyer_name = (typeof body.buyer_name === 'string') ? body.buyer_name.trim() : '';

  if (!order_id){
    return json({ ok: false, error: 'Missing order_id.' }, 400);
  }
  if (!card_key){
    return json({ ok: false, error: 'Missing card_key.' }, 400);
  }

  const origin = new URL(request.url).origin;

  // Assignment policy: first assignment wins per order_id.
  // We still keep the composite key for support/idempotency history, but `order:${order_id}` is canonical.
  const orderKey = buildOrderKey(order_id, card_key, quantity);
  const orderIndexKey = buildOrderIndexKey(order_id);

  // Canonical lookup: if this order_id already has any assigned codes, always return them.
  let existingOrder = await getJsonKV(env, orderIndexKey);

  // Backwards compatibility: if older data only exists under the composite key, reuse that too.
  if (isInactiveOrderRecord(existingOrder)) existingOrder = null;

  if (!existingOrder){
    existingOrder = await getJsonKV(env, orderKey);
    if (isInactiveOrderRecord(existingOrder)) existingOrder = null;
  }

  if (existingOrder && typeof existingOrder === 'object' && Array.isArray(existingOrder.codes) && existingOrder.codes.length){
    const codes = existingOrder.codes.map(String);
    const existing_card_key = String(existingOrder.card_key || card_key);
    const existing_quantity = Number(existingOrder.quantity || quantity || codes.length || 1);
    const assignment_conflict = (existing_card_key !== card_key) || (existing_quantity !== quantity);
    const assignmentState = await inspectAssignmentState(env, codes);
    const message_text = buildMessage({ codes, origin, buyerName: buyer_name || existingOrder.buyer_name || '' });
    return json({
      ok: true,
      existing: true,
      assignment_conflict,
      can_void_unactivated: !!assignmentState.can_void_unactivated,
      assignment_state: assignmentState.assignment_state,
      order_id,
      card_key: existing_card_key,
      quantity: existing_quantity,
      requested_card_key: card_key,
      requested_quantity: quantity,
      codes,
      etsy_message: message_text,
      message_text,
    });
  }

  const prefix = cardKeyToCodePrefix(card_key);

  const codes = [];
  for (let i = 0; i < quantity; i++){
    let code = '';
    try{
      code = await generateUniqueCode(env, prefix);
    } catch {
      return json({ ok: false, error: 'Could not generate a new code. Try again.' }, 500);
    }

    const assigned_at = new Date().toISOString();
    const acKey = `ac:${code}`;

    const acRec = {
      code,
      sku: 'single',
      status: 'assigned',
      order_id,
      buyer_name: buyer_name || null,
      assigned_at,
      bundle_index: quantity > 1 ? (i + 1) : null,
      init: { card_key },
    };

    await env.CARDS_KV.put(acKey, JSON.stringify(acRec));
    codes.push(code);
  }

  const orderRec = {
    order_id,
    card_key,
    quantity,
    codes,
    buyer_name: buyer_name || null,
    status: 'assigned',
    assigned_at: new Date().toISOString(),
  };
  // Store both:
  // - composite key = idempotent assignment identity (order + card + quantity)
  // - plain order key = quick lookup/index for later redeem enrichment and support tools
  await env.CARDS_KV.put(orderKey, JSON.stringify(orderRec));
  await env.CARDS_KV.put(orderIndexKey, JSON.stringify(orderRec));

  const message_text = buildMessage({ codes, origin, buyerName: buyer_name });
  return json({
    ok: true,
    existing: false,
    order_id,
    card_key,
    quantity,
    codes,
    etsy_message: message_text,
    message_text,
  });
}


// --- session cookie verification ---

const SESSION_COOKIE_NAME = 'cc_fulfill';

function getCookie(request, name){
  const header = request.headers.get('Cookie') || '';
  const parts = header.split(/;\s*/);
  for (const part of parts){
    const eq = part.indexOf('=');
    if (eq === -1) continue;
    const k = part.slice(0, eq).trim();
    if (k === name) return part.slice(eq + 1);
  }
  return '';
}

function base64UrlToUint8Array(b64url){
  const b64 = b64url.replace(/-/g, '+').replace(/_/g, '/');
  const pad = b64.length % 4;
  const padded = pad ? b64 + '='.repeat(4 - pad) : b64;
  const bin = atob(padded);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function hmacSha256(secret, data){
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    'raw',
    enc.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(data));
  return new Uint8Array(sig);
}

function timingSafeEqual(a, b){
  if (a.length !== b.length) return false;
  let out = 0;
  for (let i = 0; i < a.length; i++) out |= (a[i] ^ b[i]);
  return out === 0;
}

async function verifySessionCookie(request, sessionSecret){
  const token = String(getCookie(request, SESSION_COOKIE_NAME) || '').trim();
  if (!token) return false;

  const dot = token.lastIndexOf('.');
  if (dot === -1) return false;

  const payloadB64 = token.slice(0, dot);
  const sigB64 = token.slice(dot + 1);

  let payloadJson = '';
  try{
    payloadJson = new TextDecoder().decode(base64UrlToUint8Array(payloadB64));
  } catch {
    return false;
  }

  let payload;
  try{
    payload = JSON.parse(payloadJson);
  } catch {
    return false;
  }

  const exp = Number(payload?.exp);
  if (!Number.isFinite(exp) || exp <= Date.now()) return false;

  const expectedSig = await hmacSha256(sessionSecret, payloadB64);
  let providedSig;
  try{
    providedSig = base64UrlToUint8Array(sigB64);
  } catch {
    return false;
  }

  return timingSafeEqual(expectedSig, providedSig);
}