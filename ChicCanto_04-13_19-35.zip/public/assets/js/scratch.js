import { SCRATCH_RADIUS_PX, SCRATCH_THRESHOLD } from './config.js';


// Optional textured brush for scratch (falls back to circle if it can't load)
// Put your brush at: public/assets/img/brush.png (served as /assets/img/brush.png)
const BRUSH_SRC = '/assets/img/brush.png';
let _brushImg = null;
let _brushTried = false;

function ensureBrush(){
  if (_brushTried) return;
  _brushTried = true;
  const img = new Image();
  img.decoding = 'async';
  img.onload = () => { _brushImg = img; };
  img.onerror = () => { _brushImg = null; };
  img.src = BRUSH_SRC;
}

/**
 * Foil cover: drawn on canvas so the scratch layer looks like metallic foil.
 * - Default foil = "silver"
 * - Optional: set <html data-foil="gold"> (or "silver") to switch globally (no UI toggle).
 * - Optional: override colors with CSS variables on :root:
 *   --scratch-foil-base, --scratch-foil-hi, --scratch-foil-mid, --scratch-foil-dark, --scratch-foil-text
 */

function getFoilPalette(){
  const root = document.documentElement;
  const cs = getComputedStyle(root);
  const mode = (root.dataset.foil || 'silver').toLowerCase().trim();
  const defaults = {
    silver: {
      dark: '#7a7a7a',
      hi:   '#bebebe',
      mid:  '#a0a0a0',
      base: '#a0a0a0',
      text: 'rgba(255,255,255,0.72)'
    },
    gold: {
      dark: '#8d6a36',
      hi:   '#efcd65',
      mid:  '#c9a050',
      base: '#c9a050',
      text: 'rgba(255,255,255,0.82)'
    },
    bronze: {
      dark: '#6b3a1f',
      hi:   '#d4894a',
      mid:  '#a05c32',
      base: '#a05c32',
      text: 'rgba(255,255,255,0.80)'
    },
    rose: {
      dark: '#e6a5a5',
      hi:   '#f7cac9',
      mid:  '#eebaba',
      base: '#eebaba',
      text: 'rgba(255,255,255,0.80)'
    }
  };
  const d = defaults[mode] || defaults.silver;
  const pick = (name, fallback) => (cs.getPropertyValue(name) || '').trim() || fallback;
  return {
    dark: pick('--scratch-foil-dark', d.dark),
    hi:   pick('--scratch-foil-hi',   d.hi),
    mid:  pick('--scratch-foil-mid',  d.mid),
    base: pick('--scratch-foil-base', d.base),
    text: pick('--scratch-foil-text', d.text),
    mode
  };
}

function resizeCanvasToElement(canvas){
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
  canvas.width = Math.floor(rect.width * dpr);
  canvas.height = Math.floor(rect.height * dpr);
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { ctx, rect };
}

function paintFoilBase(ctx, rect, pal){
  const g = ctx.createLinearGradient(0, 0, rect.width, rect.height);
  g.addColorStop(0, pal.dark);
  g.addColorStop(1, pal.hi);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, rect.width, rect.height);
}


function paintHintText(ctx, rect, pal, hintStyle){
  if (hintStyle === 'none') return;
  ctx.fillStyle = pal.text;
  if (hintStyle === 'thin'){
    ctx.font = '400 11px Inter, ui-sans-serif, system-ui';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.letterSpacing = '0.3em';
    ctx.fillText('SCRATCH', rect.width/2, rect.height/2);
    ctx.letterSpacing = '0px';
  } else {
    ctx.font = '700 12px ui-sans-serif, system-ui';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('scratch', rect.width/2, rect.height/2);
  }
}

function paintCover(ctx, rect, { sheenX = null, hintStyle } = {}){
  ctx.save();

  const pal = getFoilPalette();

  // Foil base
  paintFoilBase(ctx, rect, pal);

  if (typeof sheenX === 'number') {
    const w = rect.width;
    const h = rect.height;
    const skew = w;
    const bandHalfW = Math.max(8, w * 0.20);
    ctx.save();
    ctx.transform(1, 0, -skew / h, 1, 0, 0);
    const mappedX = sheenX + skew / 2;
    ctx.beginPath();
    ctx.rect(mappedX - bandHalfW, 0, bandHalfW * 2, h);
    ctx.clip();
    const sg = ctx.createLinearGradient(mappedX - bandHalfW, 0, mappedX + bandHalfW, 0);
    sg.addColorStop(0.0, 'rgba(255,255,255,0)');
    sg.addColorStop(0.3, 'rgba(255,255,255,0.055)');
    sg.addColorStop(0.5, 'rgba(255,255,255,0.10)');
    sg.addColorStop(0.7, 'rgba(255,255,255,0.055)');
    sg.addColorStop(1.0, 'rgba(255,255,255,0)');
    ctx.globalCompositeOperation = 'screen';
    ctx.fillStyle = sg;
    ctx.fillRect(mappedX - bandHalfW, 0, bandHalfW * 2, h);
    ctx.globalCompositeOperation = 'source-over';
    ctx.restore();
  }

  // Hint text
  paintHintText(ctx, rect, pal, hintStyle);

  ctx.restore();
}

function percentCleared(canvas){
  const ctx = canvas.getContext('2d');
  const { width, height } = canvas;
  const data = ctx.getImageData(0,0,width,height).data;

  // count pixels with alpha == 0 (fully cleared)
  let cleared = 0;
  const total = width * height;
  for (let i=3; i<data.length; i+=4){
    if (data[i] === 0) cleared++;
  }
  return cleared / total;
}

export function attachScratchTile(canvas, { onScratched, hintStyle }){
  let isDown = false;
  let scratched = false;
  let hasInteracted = false;
  let lastClientX = 0;
  let lastClientY = 0;

  let { ctx, rect } = resizeCanvasToElement(canvas);
  paintCover(ctx, rect, { hintStyle });

  // Begin loading brush immediately (non-blocking)
  ensureBrush();

  // Make sure touch scrolling doesn't interfere with scratching
  canvas.style.touchAction = 'none';

  // --- Sheen (guidance) animation ---
  // Stops as soon as the user interacts (so it won't distract).
  let rafId = null;
  let start = performance.now();

  function startSheen(){
    stopSheen();
    start = performance.now();

    const loop = (t) => {
      if (scratched || hasInteracted) return;

      const elapsed = t - start;
      const period = 2500;
      const p = (elapsed % period) / period;

      // Sweep fully off-canvas -> fully off-canvas (prevents cut-off/popping)
      const w = rect.width;
      const bandHalfW = Math.max(8, w * 0.20);
      const skew = w;
      const startX = -bandHalfW * 2 - skew;
      const endX = w + bandHalfW * 2;
      const x = startX + (endX - startX) * p;

      // Redraw full cover each frame (only while untouched).
      paintCover(ctx, rect, { sheenX: x, hintStyle });

      rafId = requestAnimationFrame(loop);
    };

    rafId = requestAnimationFrame(loop);
  }

  function stopSheen(){
    if (rafId){
      cancelAnimationFrame(rafId);
      rafId = null;
    }
  }

  startSheen();

  function scratchStamp(localX, localY){
    ctx.save();
    ctx.globalCompositeOperation = 'destination-out';

    if (_brushImg && _brushImg.complete && _brushImg.naturalWidth){
      // Textured brush stamp for a more natural scratch edge
      const size = SCRATCH_RADIUS_PX * 2.6;
      ctx.imageSmoothingEnabled = true;
      ctx.drawImage(_brushImg, localX - size/2, localY - size/2, size, size);
    } else {
      // Fallback: original circle brush
      ctx.beginPath();
      ctx.arc(localX, localY, SCRATCH_RADIUS_PX, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  }

  function scratchAt(clientX, clientY){
    const r = canvas.getBoundingClientRect();
    scratchStamp(clientX - r.left, clientY - r.top);
  }

  function scratchSegment(fromClientX, fromClientY, toClientX, toClientY){
    const r = canvas.getBoundingClientRect();
    const x0 = fromClientX - r.left;
    const y0 = fromClientY - r.top;
    const x1 = toClientX - r.left;
    const y1 = toClientY - r.top;

    const dx = x1 - x0;
    const dy = y1 - y0;
    const dist = Math.hypot(dx, dy);

    // Stamp spacing: small enough to feel continuous
    const step = Math.max(3, SCRATCH_RADIUS_PX * 0.55);
    const n = Math.max(1, Math.ceil(dist / step));

    for (let i = 0; i <= n; i++){
      const t = i / n;
      scratchStamp(x0 + dx * t, y0 + dy * t);
    }
  }

  
  function finishCheck(){
    if (scratched) return;
    // expensive, only check at pointer up
    const p = percentCleared(canvas);
    if (p >= SCRATCH_THRESHOLD){
      scratched = true;
      stopSheen();
      onScratched?.();
    }
  }

  function onDown(e){
    if (scratched) return;
    hasInteracted = true;
    stopSheen();

    // Make sure brush is loading (safe to call repeatedly)
    ensureBrush();

    isDown = true;
    canvas.setPointerCapture?.(e.pointerId);

    // Prevent scroll / pull-to-refresh while scratching
    e.preventDefault?.();

    lastClientX = e.clientX;
    lastClientY = e.clientY;
    scratchAt(e.clientX, e.clientY);
  }
  function onMove(e){
    if (!isDown || scratched) return;

    e.preventDefault?.();

    // Stamp along the path for continuous scratch
    scratchSegment(lastClientX, lastClientY, e.clientX, e.clientY);
    lastClientX = e.clientX;
    lastClientY = e.clientY;
  }
  function onUp(){
    if (!isDown) return;
    isDown = false;
    finishCheck();
  }

  canvas.addEventListener('pointerdown', onDown);
  canvas.addEventListener('pointermove', onMove);
  canvas.addEventListener('pointerup', onUp);
  canvas.addEventListener('pointercancel', onUp);

  window.addEventListener('resize', () => {
    ({ ctx, rect } = resizeCanvasToElement(canvas));

    if (scratched){
      // Keep revealed on resize.
      ctx.clearRect(0, 0, rect.width, rect.height);
      stopSheen();
      return;
    }

    paintCover(ctx, rect, { hintStyle });
    if (!hasInteracted) startSheen();
  });

  return {
    reset(){
      ({ ctx, rect } = resizeCanvasToElement(canvas));
      scratched = false;
      isDown = false;
      hasInteracted = false;
      paintCover(ctx, rect, { hintStyle });
      startSheen();
    },
    forceReveal(){
      ({ ctx, rect } = resizeCanvasToElement(canvas));
      ctx.clearRect(0,0,rect.width,rect.height);
      scratched = true;
      isDown = false;
      hasInteracted = true;
      stopSheen();
    }
  };
}
