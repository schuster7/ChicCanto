import { qs, qsa, copyText, formatIso, getTokenFromUrl } from './utils.js';
import { getRevealOptions, RANDOM_KEY, tierIconSrc, setTileSet } from './config.js';
import { getCardTheme, getResolvedMsgTheme } from './card-themes.js';
import { getCard, getCardAsync, ensureCard, saveCard, setConfigured, setConfiguredAndWait, setRevealed, setRevealedAndWait } from './store.js';
import { attachScratchTile } from './scratch.js';
import { renderMessageSetup, renderMessageScratch, renderMessageRevealed } from './game-message.js';

function isLikelyInAppBrowser(){
  const ua = navigator.userAgent || '';
  // Heuristic: FB/IG/Messenger in-app browsers usually expose these tokens.
  return /(FBAN|FBAV|FB_IAB|FB4A|FBMD|Instagram|Messenger)/i.test(ua);
}

function isMobileOrTablet(){
  const ua = navigator.userAgent || '';
  // Coarse filter: only gate on handheld devices.
  return /Android|iPhone|iPad|iPod/i.test(ua);
}

function renderInAppBlocked(container, token){
  const origin = window.location.origin;
  const cardUrl = makeAbsoluteCardLink(token);

  container.innerHTML = `
    <main class="page-main">
      <div class="container">
        <section class="flow-screen">
          <div class="flow-layout">
            <div class="flow-intro">
              <h1 class="flow-title">Open in your browser</h1>
              <p class="flow-lead muted panel-meta">
                This chat app is opening the card inside an in-app browser. That can reset the card while scratching.
                Copy the link and open it in your phone’s browser.
              </p>
            </div>

            <section class="flow-panel--combined panel panel--glass panel--padded" aria-label="Open in browser">
              <div class="panel-meta">
                <div>Step 1</div>
                <div class="flow-panel__hint">Copy the link</div>
              </div>

              <div class="control-grid">
                <div class="field">
                  <label class="label" for="cardLink">Card link</label>
                  <input class="input" id="cardLink" readonly type="text" value="${cardUrl}" />
                </div>

                <div class="actions">
                  <button class="btn primary" id="copyLinkBtn" type="button">Copy link</button>
                </div>

                <div class="muted small" style="margin-top: 2px;">
                  Use the <strong>…</strong> menu in your chat app and choose <strong>Open in browser</strong> (or similar).
                  If you can’t find that option, paste the copied link into your browser.
                </div>
              </div>
            </section>
          </div>
        </section>
      </div>
    </main>
  `;

  const copyBtn = container.querySelector('#copyLinkBtn');
  const input = container.querySelector('#cardLink');
  if (copyBtn && input){
    copyBtn.addEventListener('click', async () => {
      try{
        await navigator.clipboard.writeText(cardUrl);
        copyBtn.textContent = 'Copied';
        setTimeout(() => (copyBtn.textContent = 'Copy link'), 1200);
      }catch{
        input.focus();
        input.select();
        document.execCommand('copy');
        copyBtn.textContent = 'Copied';
        setTimeout(() => (copyBtn.textContent = 'Copy link'), 1200);
      }
    });
  }
}


// --- Patch: ensure "configured" persists so share links work ---
// Some flows update choice/reveal_amount but forget to flip card.configured.
// This helper force-merges the configured state into localStorage for the current token.
function _scStorageKey(token){
  return `sc:card:${token}`;
}

function _forcePersistConfiguredCard(token, nextCard){
  try{
    const key = _scStorageKey(token);
    const raw = localStorage.getItem(key);
    if(raw){
      try{
        const obj = JSON.parse(raw);
        if(obj && typeof obj === 'object' && obj.card && typeof obj.card === 'object'){
          localStorage.setItem(key, JSON.stringify({ ...obj, card: { ...obj.card, ...nextCard } }));
          return;
        }
        if(obj && typeof obj === 'object'){
          localStorage.setItem(key, JSON.stringify({ ...obj, ...nextCard }));
          return;
        }
      }catch(_e){}
    }
    localStorage.setItem(key, JSON.stringify({ ...nextCard }));
  }catch(_e){
    // Ignore storage failures (private mode/quota/etc.)
  }
}
// --- End patch ---


// Inline SVG support (for reliable rendering/export and consistent sizing)
const _INLINE_SVG_CACHE = new Map();

// Token format validation (keeps obviously invalid links from depending on API reachability)
// Supported formats: short (8-4 hex) and full UUID.
const TOKEN_RE = /^([0-9a-f]{8}-[0-9a-f]{4}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i;

// Global flag: public preview mode (scratch-only, no share links).
let PREVIEW_MODE = false;


// --- UX helpers: toast + safe copy/share (iPhone friendly) ---
let _toastTimer = null;
function toast(message){
  try{
    let el = document.getElementById('appToast');
    if (!el){
      el = document.createElement('div');
      el.id = 'appToast';
      el.style.position = 'fixed';
      el.style.left = '50%';
      el.style.bottom = '18px';
      el.style.transform = 'translateX(-50%)';
      el.style.zIndex = '9999';
      el.style.maxWidth = '92vw';
      el.style.padding = '10px 12px';
      el.style.borderRadius = '12px';
      el.style.background = 'rgba(0,0,0,0.85)';
      el.style.color = '#fff';
      el.style.fontSize = '14px';
      el.style.lineHeight = '1.2';
      el.style.opacity = '0';
      el.style.pointerEvents = 'none';
      el.style.transition = 'opacity 160ms ease';
      document.body.appendChild(el);
    }
    el.textContent = String(message || '');
    // force reflow for transition reliability
    void el.offsetHeight;
    el.style.opacity = '1';
    if (_toastTimer) clearTimeout(_toastTimer);
    _toastTimer = setTimeout(() => {
      el.style.opacity = '0';
    }, 1600);
  }catch{
    // no-op
  }
}

function isLocalhost(){
  const h = String(window.location.hostname || '').toLowerCase();
  return h === 'localhost' || h === '127.0.0.1' || h === '0.0.0.0';
}

async function safeCopyLink(url){
  if (!url) return false;
  if (isLocalhost()){
    toast('You are on localhost. Use your LAN IP to share links across devices.');
  }
  // Always copy URL only (no prefix text), but resolve relative URLs safely.
  const u = String(new URL(String(url), window.location.href));
  const ok = await copyText(u);
  toast(ok ? 'Link copied' : 'Copy failed');
  return ok;
}

async function safeShareLink(url, text){
  if (!url) return false;
  if (isLocalhost()){
    toast('You are on localhost. Use your LAN IP to share links across devices.');
  }
  const u = String(new URL(url, window.location.href));

  // iOS (especially on http) is picky. Share URL-only first for max compatibility.
  if (navigator.share){
    try{
      await navigator.share({ title: 'ChicCanto', url: u });
      return true;
    }catch{
      // cancelled or failed, fall back to copy
    }
  }

  // Fallback: copy (includes optional text + url)
  return safeCopyLink(u);
}

function _sanitizeSvgMarkup(markup) {
  return String(markup)
    .replace(/<\?xml[\s\S]*?\?>\s*/gi, '')
    .replace(/<!doctype[\s\S]*?>\s*/gi, '')
    .replace(/<!--[\s\S]*?-->\s*/g, '')
    .trim();
}

async function _fetchSvgMarkup(url) {
  const abs = new URL(url, window.location.href).toString();
  if (_INLINE_SVG_CACHE.has(abs)) return _INLINE_SVG_CACHE.get(abs);

  const p = fetch(abs, { cache: 'force-cache' })
    .then((r) => {
      if (!r.ok) throw new Error(`Failed to fetch SVG: ${r.status} ${r.statusText}`);
      return r.text();
    })
    .then(_sanitizeSvgMarkup);

  _INLINE_SVG_CACHE.set(abs, p);
  return p;
}

async function _replaceImgWithInlineSvg(img) {
  const src = img.getAttribute('src');
  if (!src) return;

  // Only handle SVG sources.
  if (!/\.svg(\?|#|$)/i.test(src)) return;

  const alt = img.getAttribute('alt') || '';

  const markup = await _fetchSvgMarkup(src);
  const tpl = document.createElement('template');
  tpl.innerHTML = markup;
  const svg = tpl.content.querySelector('svg');
  if (!svg) throw new Error('No <svg> root found in fetched markup');

  // Let CSS control sizing.
  svg.removeAttribute('width');
  svg.removeAttribute('height');

  // Preserve any classes from the original <img>.
  if (img.className) {
    const existing = svg.getAttribute('class');
    svg.setAttribute('class', existing ? `${existing} ${img.className}` : img.className);
  }

  // Accessibility
  if (alt) {
    svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', alt);
    svg.removeAttribute('aria-hidden');
  } else {
    svg.setAttribute('aria-hidden', 'true');
    svg.removeAttribute('role');
    svg.removeAttribute('aria-label');
  }
  svg.setAttribute('focusable', 'false');

  img.replaceWith(svg);
}

async function hydrateInlineSvgs(root = document) {
  const imgs = Array.from(root.querySelectorAll('img[data-inline-svg="true"]'));
  if (!imgs.length) return;

  await Promise.allSettled(
    imgs.map(async (img) => {
      if (img.dataset.inlineSvgHydrated === '1') return;
      img.dataset.inlineSvgHydrated = '1';
      try {
        await _replaceImgWithInlineSvg(img);
      } catch {
        // Keep the <img> fallback if anything fails.
      }
    }),
  );
}

function makeAbsoluteCardLink(token){
  const url = new URL(window.location.href);
  url.pathname = '/open/';

  // If token is malformed, don't build a share link.
  if (!TOKEN_RE.test(token)) return null;

  const params = new URLSearchParams();
  params.set('token', token);
  // Cache buster: helps Messenger/Meta fetch fresh HTML instead of a stale cached copy.
  params.set('v', Date.now().toString(36));
  url.search = '?' + params.toString();
  url.hash = '';
  return url.toString();
}

function uniq(arr){ return Array.from(new Set(arr)); }

function clearActionsBar(){
  const el = document.getElementById('cardActions');
  if (el) el.innerHTML = '';
}

function renderCardHeaderActions(card, revealed){
  clearActionsBar();
  const el = document.getElementById('cardActions');
  if (!el || !card) return;

  // Preview mode: no copy/share link (token is not meant to be shared).
  // Only show result actions after reveal.
  if (PREVIEW_MODE){

    const mkBtn = (label) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'btn ghost';
      b.textContent = label;
      return b;
    };

    const saveBtn = mkBtn('Save image');
    saveBtn.id = 'savePngBtn';
    saveBtn.addEventListener('click', async () => {
      if (saveBtn.disabled) return;
      try{
        saveBtn.disabled = true;
        const prev = saveBtn.textContent;
        saveBtn.textContent = 'Saving...';
        await exportRevealedPng(card);
        saveBtn.textContent = prev;
      }catch (err){
        console.error('Image export failed:', err);
        alert('Could not save image. Please try again.');
      }finally{
        saveBtn.disabled = false;
        saveBtn.textContent = 'Save image';
      }
    }, { passive: true });
    el.appendChild(saveBtn);

    const shareBtn = mkBtn('Share result');
    shareBtn.id = 'shareResultBtn';
    shareBtn.addEventListener('click', async () => {
      try{
        // In preview, sharing the URL is not meaningful, but you may still want the share sheet.
        // If you prefer, change this to share text only.
        const url = makeAbsoluteCardLink(card.token);
        const opt = resolveOptionFromCard(card);
        const label = opt && opt.label ? `Scratch card result: ${opt.label}` : 'Scratch card result';
        await safeShareLink(url, label);
      }catch (e){
        console.error('Share error:', e);
      }
    }, { passive: true });
    el.appendChild(shareBtn);

    // Preview-only: let testers jump to activation at any time.
    const activateA = document.createElement('a');
    activateA.className = 'btn ghost';
    activateA.href = '/activate/';
    activateA.textContent = 'Activate';
    el.appendChild(activateA);

    return;
  }

  // Normal mode: existing behavior
  const url = makeAbsoluteCardLink(card.token);

  const mkBtn = (label) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'btn ghost';
    b.textContent = label;
    return b;
  };

  const copyBtn = mkBtn('Copy link');
  copyBtn.addEventListener('click', async () => {
    await safeCopyLink(url, 'Scratch card link');
    copyBtn.disabled = true;
    copyBtn.textContent = 'Copied';
    setTimeout(() => {
      copyBtn.textContent = 'Copy link';
      copyBtn.disabled = false;
    }, 1200);
  }, { passive: true });

  el.appendChild(copyBtn);

  if (!revealed) return;

  const saveBtn = mkBtn('Save image');
  saveBtn.id = 'savePngBtn';
  saveBtn.addEventListener('click', async () => {
    if (saveBtn.disabled) return;
    try{
      saveBtn.disabled = true;
      const prev = saveBtn.textContent;
      saveBtn.textContent = 'Saving...';
      await exportRevealedPng(card);
      saveBtn.textContent = prev;
    }catch (err){
      console.error('Image export failed:', err);
      alert('Could not save image. Please try again.');
    }finally{
      saveBtn.disabled = false;
      saveBtn.textContent = 'Save image';
    }
  }, { passive: true });

  el.appendChild(saveBtn);

  const shareBtn = mkBtn('Share result');
  shareBtn.id = 'shareResultBtn';
  shareBtn.addEventListener('click', async () => {
    try{
      const opt = resolveOptionFromCard(card);
      const label = opt && opt.label ? `Scratch card result: ${opt.label}` : 'Scratch card result';
      await safeShareLink(url, label);
    }catch (e){
      console.error('Share error:', e);
      await safeCopyLink(url, 'Scratch card result');
    }
  }, { passive: true });

  el.appendChild(shareBtn);
}



function renderRevealedActions(card){
  // Always show header actions (Copy link). Extra actions only when revealed.
  renderCardHeaderActions(card, !!(card && card.revealed));
}

function _blobDownload(blob, filename){
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

function _roundedRectPath(ctx, x, y, w, h, r){
  // Canvas rounded-rect path helper (no ctx.roundRect dependency).
  const rr = Math.max(0, Math.min(r, Math.min(w, h) / 2));
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
}

async function _fetchAsDataUrl(url){
  const res = await fetch(url, { cache: 'force-cache' });
  if (!res.ok) throw new Error('Fetch failed: ' + url + ' (' + res.status + ')');
  const buf = await res.arrayBuffer();
  const bytes = new Uint8Array(buf);

  // Convert bytes to base64 in chunks to avoid "Maximum call stack size exceeded"
  // when using String.fromCharCode(...largeArray) on large files (JPEGs etc.).
  let binary = '';
  const chunkSize = 8192;
  for (let i = 0; i < bytes.length; i += chunkSize){
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode.apply(null, chunk);
  }
  const b64 = btoa(binary);

  const ext = url.split('.').pop().toLowerCase();
  const mime =
    ext === 'woff2' ? 'font/woff2' :
    ext === 'woff' ? 'font/woff' :
    ext === 'svg' ? 'image/svg+xml' :
    ext === 'png' ? 'image/png' :
    ext === 'jpg' || ext === 'jpeg' ? 'image/jpeg' :
    'application/octet-stream';
  return `data:${mime};base64,${b64}`;
}

async function _embedInterFontCss(){
  // Best-effort: embed the self-hosted Inter fonts into the SVG snapshot.
  // If any file is missing, we continue without embedding.
  const candidates = [
    { weight: 400, path: '/assets/fonts/inter-v20-latin-regular.woff2' },
    { weight: 500, path: '/assets/fonts/inter-v20-latin-500.woff2' },
    { weight: 700, path: '/assets/fonts/inter-v20-latin-700.woff2' },
  ];

  const rules = [];
  for (const c of candidates){
    try{
      const dataUrl = await _fetchAsDataUrl(c.path);
      rules.push(`
@font-face{
  font-family:"Inter";
  font-style:normal;
  font-weight:${c.weight};
  src:url("${dataUrl}") format("woff2");
}`);
    } catch {
      // ignore
    }
  }

  return rules.join('\n');
}

function _copyComputedStyles(sourceEl, targetEl){
  const cs = getComputedStyle(sourceEl);
  let cssText = '';
  for (let i = 0; i < cs.length; i++){
    const prop = cs[i];
    const val = cs.getPropertyValue(prop);
    // Skip properties that can break XML parsing or are irrelevant.
    if (!val) continue;
    cssText += `${prop}:${val};`;
  }
  targetEl.setAttribute('style', cssText);
}

function _inlineStylesDeep(sourceRoot, targetRoot){
  const sourceEls = [sourceRoot, ...sourceRoot.querySelectorAll('*')];
  const targetEls = [targetRoot, ...targetRoot.querySelectorAll('*')];

  for (let i = 0; i < sourceEls.length; i++){
    const s = sourceEls[i];
    const t = targetEls[i];
    if (!t) continue;
    _copyComputedStyles(s, t);
  }
}

function _makeSvgSnapshotMarkup(node, width, height, embeddedCss){
  const serializer = new XMLSerializer();
  const xhtml = serializer.serializeToString(node);

  const safeCss = (embeddedCss || '').replace(/<\/style>/g, '</sty' + 'le>');
  return `
<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
  <foreignObject width="100%" height="100%">
    <div xmlns="http://www.w3.org/1999/xhtml">
      <style>${safeCss}</style>
      ${xhtml}
    </div>
  </foreignObject>
</svg>`.trim();
}

async function exportRevealedPng(card, opts = {}){
  // Only run on revealed state.
  if (!card || !card.revealed) throw new Error('Card not revealed');

  // Ensure the current view is fully rendered and fonts are ready.
  if (document.fonts && document.fonts.ready){
    // Avoid hanging forever.
    await Promise.race([
      document.fonts.ready,
      new Promise((r) => setTimeout(r, 1500)),
    ]);
  }
  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));

  const stage = document.querySelector('.scratch-stage');
  if (!stage) throw new Error('Missing .scratch-stage');

  // --- Step A: Resolve the card background image BEFORE cloning ---
  // Mobile Safari cannot reliably paint images inside SVG foreignObject.
  // Our fix: load the background image separately, paint it directly onto the
  // canvas, and remove it from the clone so foreignObject never sees it.
  // Canvas drawImage() works everywhere (desktop + mobile).

  let bgImageForCanvas = null;  // Will hold a loaded <img> element, or null.

  try{
    // The card background is a <picture class="card-bg"> inside .scratch-stage.
    // The browser picks bg-mobile.jpg or bg-desktop.jpg based on screen width.
    // We read currentSrc from the live DOM to get whichever the browser chose.
    const livePicture = stage.querySelector('picture.card-bg');
    if (livePicture){
      const liveImg = livePicture.querySelector('img');
      const resolvedUrl = liveImg
        ? (liveImg.currentSrc || liveImg.getAttribute('src') || '').trim()
        : '';

      if (resolvedUrl && !resolvedUrl.startsWith('data:') && !resolvedUrl.startsWith('blob:')){
        const absUrl = new URL(resolvedUrl, window.location.href);

        // Only inline same-origin images (security restriction).
        if (absUrl.origin === window.location.origin){
          // Fetch as data-URL so it can survive the canvas security check.
          const dataUrl = await _fetchAsDataUrl(absUrl.href);

          // Pre-load into an <img> so we can drawImage() it onto the canvas later.
          bgImageForCanvas = await new Promise((resolve, reject) => {
            const pic = new Image();
            pic.decoding = 'async';
            pic.onload = () => resolve(pic);
            pic.onerror = () => reject(new Error('BG image preload failed'));
            pic.src = dataUrl;
          });
        }
      }
    }
  }catch(bgErr){
    // If the background fails to load, we continue without it.
    // The export will still contain all other card elements (icons, text, etc.).
    console.warn('Image export: background preload failed, continuing without it.', bgErr);
    bgImageForCanvas = null;
  }

  // --- Step B: Clone the stage and prepare it for SVG serialization ---

  const clone = stage.cloneNode(true);
  clone.classList.add('is-exporting');

  // Ensure no shadow/filters on the clone root.
  clone.style.boxShadow = 'none';
  clone.style.filter = 'none';

  // Helper: resolve a URL to absolute same-origin, or null.
  const _toAbsSameOrigin = (maybeUrl) => {
    if (!maybeUrl) return null;
    const u = String(maybeUrl).trim();
    if (!u || u.startsWith('data:') || u.startsWith('blob:')) return null;
    try{
      const abs = new URL(u, window.location.href);
      if (abs.origin !== window.location.origin) return null;
      return abs.href;
    }catch{
      return null;
    }
  };

  // DO NOT remove the <picture class="card-bg"> yet.
  // _inlineStylesDeep (below) walks source and clone by flat index.
  // If the clone has fewer elements, every style after the gap lands on the
  // wrong element and the entire layout breaks. We hide it AFTER style copying.

  // Inline all <img> elements (tile icons, title SVG, card-bg img) as data-URLs.
  // The source and clone still have matching element counts at this point.
  try{
    const imgsSrc = stage.querySelectorAll('img');
    const imgsDst = clone.querySelectorAll('img');
    const n = Math.min(imgsSrc.length, imgsDst.length);

    for (let i = 0; i < n; i++){
      const resolved = (imgsSrc[i].currentSrc || imgsSrc[i].getAttribute('src') || '').trim();
      const abs = _toAbsSameOrigin(resolved);
      if (!abs) continue;

      const dataUrl = await _fetchAsDataUrl(abs);
      imgsDst[i].setAttribute('src', dataUrl);
      imgsDst[i].removeAttribute('srcset');
      imgsDst[i].removeAttribute('sizes');
    }
  }catch{}

  // --- Step C: Mount offscreen, inline computed styles, serialize to SVG ---

  const wrap = document.createElement('div');
  wrap.style.position = 'fixed';
  wrap.style.left = '-10000px';
  wrap.style.top = '0';
  wrap.style.width = stage.getBoundingClientRect().width + 'px';
  wrap.style.height = stage.getBoundingClientRect().height + 'px';
  wrap.style.zIndex = '-1';
  wrap.style.pointerEvents = 'none';
  wrap.appendChild(clone);
  document.body.appendChild(wrap);

  try{
    // Inline all computed CSS into the clone so the SVG snapshot is self-contained.
    // IMPORTANT: clone still has the same element count as source at this point.
    _inlineStylesDeep(stage, clone);

    // NOW it is safe to remove the <picture class="card-bg"> from the clone.
    // Style copying is done, so removing elements no longer misaligns anything.
    // The background will be painted directly on the canvas (Step D).
    try{
      clone.querySelectorAll('picture.card-bg').forEach((pic) => pic.remove());
    }catch{}

    // Make the clone's background TRANSPARENT so the canvas-painted JPEG
    // shows through the SVG foreignObject overlay. _inlineStylesDeep copied
    // the live stage's opaque background-color (e.g. #1c1e1e) onto the clone,
    // which would otherwise completely cover the JPEG underneath.
    clone.style.backgroundImage = 'none';
    clone.style.backgroundColor = 'transparent';
    clone.style.background = 'transparent';

    const rect = stage.getBoundingClientRect();

    // Export at 2x for crisp PNGs on retina screens.
    const scale = 2;

    const w0 = Math.max(1, Math.round(rect.width));
    const h0 = Math.max(1, Math.round(rect.height));

    // Force the cloned root to the exact on-screen size so % widths resolve.
    clone.style.width = w0 + 'px';
    clone.style.height = h0 + 'px';
    clone.style.maxWidth = 'none';
    clone.style.margin = '0';
    clone.style.display = 'block';

    const embeddedFontCss = await _embedInterFontCss();

    // SVG snapshot: contains everything EXCEPT the background image.
    const svgMarkup = _makeSvgSnapshotMarkup(clone, w0, h0, embeddedFontCss);
    const svgDataUrl = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgMarkup);

    const svgImg = new Image();
    svgImg.decoding = 'async';

    await new Promise((resolve, reject) => {
      svgImg.onload = resolve;
      svgImg.onerror = () => reject(new Error('Snapshot image failed to load'));
      svgImg.src = svgDataUrl;
    });

    // --- Step D: Compose the final image on canvas ---
    // Layer order (bottom to top):
    //   1. Page-themed padding background (from card theme, falls back to dark)
    //   2. Card background image (JPEG, painted directly via canvas — works on mobile)
    //   3. SVG foreignObject overlay (text, icons, layout — no background image)
    //   4. Promo text below the card

    // Read the per-card page background for the export padding area.
    const exportBg = (() => {
      try{
        const t = getCardTheme(card.card_key);
        return (t && t.pageBg) ? t.pageBg : '#0e151a';
      }catch{ return '#0e151a'; }
    })();

    const canvas = document.createElement('canvas');

    // Padding for share-friendly exports with breathing room.
    const pad = (() => {
      const base = Math.min(w0, h0);
      return Math.max(24, Math.min(96, Math.round(base * 0.06)));
    })();

    // Extra space for branding: logo at top, promo at bottom.
    // Both areas use the same height for visual balance.
    const brandingHeight = 36;

    // Layout: topGap | card | bottomGap
    // topGap = bottomGap = pad + brandingHeight
    // Logo is vertically centered in topGap, promo in bottomGap.
    const gapHeight = pad + brandingHeight;

    const outW = w0 + pad * 2;
    const outH = gapHeight + h0 + gapHeight;

    // Y offset: card starts after the top gap.
    const cardY = gapHeight;

    canvas.width = Math.max(1, Math.round(outW * scale));
    canvas.height = Math.max(1, Math.round(outH * scale));

    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('No canvas context');

    // Work in CSS pixels; apply pixel scaling once.
    ctx.setTransform(scale, 0, 0, scale, 0, 0);

    // Layer 1: per-card background (visible as padding around the card).
    ctx.fillStyle = exportBg;
    ctx.fillRect(0, 0, outW, outH);

    // Layer 1b: ChicCanto SVG logo at top center.
    // Loaded as a data-URL image so it renders crisp at any scale.
    try{
      const logoDataUrl = await _fetchAsDataUrl('/assets/img/logo1.svg');
      const logoImg = await new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = () => reject(new Error('Logo load failed'));
        img.src = logoDataUrl;
      });
      // Scale logo: cap height at ~40% of branding area, cap width for subtlety.
      const logoAspect = logoImg.naturalWidth / logoImg.naturalHeight;
      const logoH = brandingHeight * 0.40;
      const logoW = Math.min(logoH * logoAspect, outW * 0.22);
      const logoX = (outW - logoW) / 2;
      const logoY = (gapHeight - logoH) / 2;
      ctx.globalAlpha = 0.38;
      ctx.drawImage(logoImg, logoX, logoY, logoW, logoH);
      ctx.globalAlpha = 1;
    }catch(_e){
      // Fallback: plain text if SVG fails to load.
      ctx.fillStyle = 'rgba(255,255,255,0.38)';
      ctx.font = 'italic 500 13px Inter, ui-sans-serif, system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('ChicCanto', outW / 2, gapHeight / 2);
    }

    // Rounded-corner clipping (matches the card's border-radius on screen).
    const r = (() => {
      try{
        const br = getComputedStyle(stage).borderTopLeftRadius || '0px';
        const n = parseFloat(br);
        return Number.isFinite(n) ? n : 0;
      }catch{
        return 0;
      }
    })();

    // Save context before clip so we can draw the promo text outside the clip region.
    ctx.save();

    if (r > 0){
      const rr = Math.min(r, Math.min(w0, h0) / 2);
      ctx.beginPath();
      _roundedRectPath(ctx, pad, cardY, w0, h0, rr);
      ctx.clip();
    }

    // Layer 2: card background image (JPEG), drawn directly on canvas.
    // This is the key mobile fix — canvas drawImage always works.
    if (bgImageForCanvas){
      ctx.drawImage(bgImageForCanvas, pad, cardY, w0, h0);
    }

    // Layer 3: SVG foreignObject (everything else: title, grid, icons, legend).
    ctx.drawImage(svgImg, pad, cardY);

    // Restore context to remove the rounded-corner clip before drawing promo text.
    ctx.restore();

    // Layer 4: promo text below the card.
    ctx.fillStyle = 'rgba(255,255,255,0.38)';
    ctx.font = '500 12px Inter, ui-sans-serif, system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const promoY = cardY + h0 + gapHeight / 2;
    ctx.fillText('Send one back?  \u2192  etsy.com/shop/ChicCanto', outW / 2, promoY);

    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.92));
    if (!blob) throw new Error('Image export failed');

    const ts = formatIso(new Date()).replace(/[:]/g, '').slice(0, 15);
    const filename = `chiccanto-${card.productId || 'card'}-${card.token}-${ts}.jpg`;

    const download = opts.download !== false;
    const outName = opts.filename || filename;

    if (download) _blobDownload(blob, outName);
    return blob;
  } finally {
    wrap.remove();
  }
}

function pickRandomOption(){
  const idx = Math.floor(Math.random() * getRevealOptions().length);
  return getRevealOptions()[idx];
}

function resolveOptionFromCard(card){
  if (card?.choice){
    const o1 = getRevealOptions().find(o => o.key === card.choice);
    if (o1) return o1;
  }
  if (card?.reveal_amount){
    const o2 = getRevealOptions().find(o => o.amount === card.reveal_amount);
    if (o2) return o2;
  }
  return getRevealOptions()[0];
}

// --- Deterministic board (no persistence needed) ---
function xfnv1a(str){
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++){
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function mulberry32(a){
  return function(){
    a |= 0;
    a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function seededRng(seedStr){ return mulberry32(xfnv1a(seedStr)); }

function shuffleWithRng(arr, rng){
  for (let i = arr.length - 1; i > 0; i--){
    const j = Math.floor(rng() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// Only the winning tier appears 3 times. Other tiers appear at most 2 times.

function buildMatch3Board(totalTiles, winTier, tiers, seedKey){
  const total = Math.max(1, Math.min(9, Number(totalTiles) || 9));
  const rng = seededRng(seedKey);

  const allTiers = tiers && tiers.length ? tiers.slice() : ['t1','t2','t3','t4'];
  const others = allTiers.filter(t => t !== winTier);

  const board = [winTier, winTier, winTier];
  const counts = { [winTier]: 3 };
  let remaining = total - 3;

  for (const t of others){
    if (remaining <= 0) break;
    const add = Math.min(2, remaining);
    for (let i = 0; i < add; i++){
      board.push(t);
      counts[t] = (counts[t] || 0) + 1;
    }
    remaining -= add;
  }

  let guard = 0;
  while (remaining > 0 && guard++ < 200){
    const t = others[Math.floor(rng() * others.length)];
    if ((counts[t] || 0) >= 2) continue;
    board.push(t);
    counts[t] = (counts[t] || 0) + 1;
    remaining--;
  }

  return shuffleWithRng(board, rng);
}

function render(container, token, card){
  // Card is expected to already exist in storage (redeem/setup creates it).
  applyTheme(card.theme_id);
  applyPageTheme(card.card_key, card.card_style, { allowDarkMode: false });

  const contentId = 'content';

  const params = new URLSearchParams(window.location.search);
  const setupParam = params.get('setup') || params.get('setup_key') || params.get('setupKey') || '';
  const hasSetupAccess = PREVIEW_MODE ? false : !!(setupParam && card.setup_key && setupParam === card.setup_key);

  // If a setup param is present, cache it for this token so we can recover sender setup
  // even if the backend redacts setup_key in intermediate responses (KV propagation, etc.).
  if (!PREVIEW_MODE && token && setupParam){
    const looksLikeKey = /^[A-Za-z0-9_-]{10,}$/.test(String(setupParam));
    if (looksLikeKey){
      try{ localStorage.setItem(`sc:setup:${token}`, String(setupParam)); }catch(_e){}
    }
  }


// Persist sender setup key locally so we can recover from accidentally opening the recipient link (token-only).
if (!PREVIEW_MODE && hasSetupAccess && token && card && card.setup_key){
  try{ localStorage.setItem(`sc:setup:${token}`, String(card.setup_key)); }catch(_e){}
}

const previewCta = PREVIEW_MODE ? `
  <div class="preview-line" role="note" aria-label="Preview notice">
    <span class="muted">Preview mode. Scratch for free. Activate to create a recipient link.</span>
  </div>
` : '';


  container.innerHTML = `
    ${previewCta}
    <div id="${contentId}"></div>
  `;

  const content = qs('#' + contentId, container);

  // Determine game type from card theme
  const _theme = getCardTheme(card.card_key);
  const _gameType = (_theme && _theme.gameType) || 'match3';

  if (card.revealed){
    applyPageTheme(card.card_key, card.card_style, { allowDarkMode: true });
    if (_gameType === 'message'){
      renderMessageRevealed(content, card);
    } else {
      renderRevealed(content, card);
    }
    return;
  }

  // Sender private link (setup param) should always show setup UI (even after configured),
  // so the buyer can copy/share the recipient link.
  if (hasSetupAccess){
    if (_gameType === 'message'){
      renderMessageSetup(content, card, container, { previewMode: PREVIEW_MODE });
    } else {
      renderSetup(content, card, container);
    }
    return;
  }

  if (!card.configured){
    // On first open from another device (Messenger, etc.), Cloudflare KV can briefly return a stale record.
    // Wait a short moment for the configured state before showing "Not ready yet".
    renderPreparing(content);

    (async () => {
      const fresh = await _waitForConfigured(token, { attempts: 15, baseDelayMs: 500 });
      if (fresh && fresh.configured){
        render(container, token, fresh);
        return;
      }
      renderNotReady(content, card);
      // Auto-refresh once after 12s as a last-chance fallback for slow KV propagation.
      setTimeout(() => {
        try{
          if (!document.querySelector('.scratch-stage')){
            window.location.reload();
          }
        }catch(_){}
      }, 12000);
    })();

    return;
  }

  applyPageTheme(card.card_key, card.card_style, { allowDarkMode: true });
  if (_gameType === 'message'){
    renderMessageScratch(content, card);
  } else {
    renderScratch(content, card);
  }
}

function renderSetup(root, card, container){
  // Ensure the correct per-card prize labels/icons are active before rendering the choice buttons.
  const cardKey = String(card?.card_key || '').trim() || 'men-novice1';
  setTileSet(cardKey);

  const tierOptions = getRevealOptions().map(o => `
      <button class="btn" data-choice="${o.key}" type="button">${o.label}</button>
    `).join('');

  const theme = getCardTheme(card.card_key);
  const thumbSrc = (theme && theme.thumbSrc) ? theme.thumbSrc : '/assets/img/thumb_men-novice1.jpg';
  const cardName = (() => {
    const raw = String(card.card_key || '').trim();
    if (!raw) return 'Selected card';
    const cleaned = raw.replace(/\d+$/, '').replace(/-/g, ' ').trim();
    return cleaned.split(/\s+/).map(w => w ? (w[0].toUpperCase() + w.slice(1)) : '').join(' ');
  })();

  root.innerHTML = `
    <div class="flow-screen stack">
      <div class="flow-layout">
        <div class="flow-intro">
          <h1 class="flow-title">Select the prize</h1>
          <p class="flow-lead muted">Pick the prize, then send the recipient link. After you confirm, you have 5 seconds to cancel.</p>
        </div>

        <section class="flow-panel--combined panel panel--glass panel--padded setup-unified" aria-label="Sender controls">
          <div class="panel-meta">
            <div>Step 2 - Setup card</div>
            <div class="flow-panel__hint">Choose prize</div>
          </div>

          <div class="setup-grid">
            <!-- Left: trust + guidance + random -->
            <div class="setup-left stack">
  <div class="setup-thumb">
    <div class="setup-thumb__media">
      <img class="card-preview__img" src="${thumbSrc}" alt="Card thumbnail" />
    </div>
    <div class="setup-thumb__info">
      <div class="mini-panel__kicker">Selected card</div>
      <div class="small muted">${cardName}</div>
    </div>
  </div>



  <div class="mini-panel">
    <div class="mini-panel__kicker" style="display:flex; align-items:center; justify-content:space-between;">
      <span>Prefer not to choose?</span>
      <span class="flow-panel__hint" style="text-transform:none; letter-spacing:0;">We pick</span>
    </div>
    <div class="small muted">Let ChicCanto pick one of the four prizes for you.</div>
    <button class="btn outline w-full" data-choice="${RANDOM_KEY}" type="button" style="margin-top:12px;">Surprise me (we choose)</button>


  </div>
</div><div class="setup-right">
              <div class="flow-section" aria-label="Prize level">
                <div class="flow-panel__head">
                  <div class="flow-panel__title">Prize level</div>
                  <div class="flow-panel__meta muted small">Locks after confirmation</div>
                </div>

                <div class="choice-grid choice-grid--4" role="group" aria-label="Choose a prize level">
                  ${tierOptions}
                </div>

                <div class="flow-status muted small" id="setupStatus"></div>
              </div>

              <div class="flow-divider" role="separator" aria-hidden="true"></div>

              <div class="flow-section" aria-label="Share link">
                <div class="flow-panel__head">
                  <div class="flow-panel__title">Recipient link</div>
                </div>

                <div class="sharebar">
                  <div class="sharebar__url" id="shareUrl">Pick a prize to generate the link</div>

                  <div class="sharebar__actions">
                    <button class="btn" id="copyBtn" type="button">Copy</button>
                    <button class="btn" id="shareBtn" type="button">Share</button>
                    <button class="btn" id="openBtn" type="button">Open as recipient</button>
                  </div>

                  <div class="sharebar__lock" id="changeRow" hidden>
                    <button class="btn" id="changeBtn" type="button">Cancel</button>
                    <div class="small muted" id="lockHint"></div>
                  </div>
                </div>

                <div class="flow-tip muted small">Tip: you can return to this setup link anytime to copy the recipient link again.</div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
`;
const shareUrlEl = qs('#shareUrl', root);
  const copyBtn = qs('#copyBtn', root);
  const shareBtn = qs('#shareBtn', root);
  const openBtn = qs('#openBtn', root);
  const changeRow = qs('#changeRow', root);
  const changeBtn = qs('#changeBtn', root);
  const lockHintEl = qs('#lockHint', root);

  let shareUrl = null;

  // Pending lock timer (lets first-time buyers realize it's irreversible without adding extra clicks)
  let pending = null; // { interval, choice, chosen }

// Cancel overlay (mobile first). Keeps the 5 second undo visible without scrolling.
let _cancelModal = null;
function _ensureCancelModal(){
  if (_cancelModal) return _cancelModal;
  const el = document.createElement('div');
  el.className = 'cc-modal cc-modal--hidden';
  el.innerHTML = `
    <div class="cc-modal__backdrop" data-cc-close="1"></div>
    <div class="cc-modal__panel" role="dialog" aria-modal="true" aria-labelledby="ccCancelTitle">
      <div class="cc-modal__title mini-panel__kicker" id="ccCancelTitle">Prize selected</div>
      <img class="cc-modal__icon" id="ccCancelIcon" alt="" style="width:86px;height:86px;display:block;margin:10px auto 12px;object-fit:contain;">
      <div class="cc-modal__prize" id="ccCancelPrize"></div>
      <div class="cc-modal__subtitle" id="ccCancelSubtitle"></div>
      <div class="cc-modal__actions">
        <button type="button" class="btn" id="ccCancelBtn">Cancel</button>
      </div>
    </div>
  `;
  document.body.appendChild(el);

  const btn = el.querySelector('#ccCancelBtn');
  const iconEl = el.querySelector('#ccCancelIcon');
  const prizeEl = el.querySelector('#ccCancelPrize');
  const subtitle = el.querySelector('#ccCancelSubtitle');

  function open(){
    el.classList.remove('cc-modal--hidden');
  }
  function close(){
    el.classList.add('cc-modal--hidden');
  }

  el.addEventListener('click', (e) => {
    const t = e.target;
    if (t && t.getAttribute && t.getAttribute('data-cc-close') === '1'){
      cancelPending();
    }
  });
  btn.addEventListener('click', () => cancelPending());

  document.addEventListener('keydown', (e) => {
    if (el.classList.contains('cc-modal--hidden')) return;
    if (e.key === 'Escape') cancelPending();
  });

  _cancelModal = { el, btn, iconEl, prizeEl, subtitle, open, close };
  return _cancelModal;
}


  function setChoiceButtonsEnabled(enabled){
    qsa('button[data-choice]', root).forEach(b => {
      b.disabled = !enabled;
      b.style.pointerEvents = enabled ? 'auto' : 'none';
    });
  }

  function resetShareUI(){
    shareUrl = null;
    shareUrlEl.textContent = 'Pick a prize to generate the link.';
    // Disable actions until a prize is selected
    copyBtn.disabled = true;

    if (shareBtn){
      shareBtn.disabled = true;
    }

    openBtn.disabled = true;

    changeRow.style.display = 'none';
    lockHintEl.textContent = '';
  }

  function enableShare(){
    shareUrlEl.textContent = shareUrl;

    copyBtn.disabled = false;

    if (shareBtn){
      shareBtn.disabled = false;
    }

    openBtn.disabled = false;

    changeRow.style.display = 'none';
    lockHintEl.textContent = '';
  }

  function showPending(choice, chosen, secondsLeft){
  const isRandom = (choice === RANDOM_KEY);
  const label = isRandom ? 'Surprise me' : (chosen?.label || 'Your choice');

  // Keep legacy inline hint text updated (harmless on desktop).
  shareUrlEl.textContent = `Selected ${label}. Locking in ${secondsLeft}…`;

  // Disable share actions while the cancel window is active.
  copyBtn.disabled = true;

  if (shareBtn){
    shareBtn.disabled = true;
  }

  openBtn.disabled = true;

  // Hide the old bottom-row cancel UI during the pending state.
  changeRow.style.display = 'none';
  lockHintEl.textContent = '';

  // Show modal overlay so mobile users always see Cancel.
  const modal = _ensureCancelModal();
  modal.prizeEl.textContent = label;
  try{
    const tier = chosen?.tier;
    const src = (!isRandom && tier) ? tierIconSrc(tier) : '';
    if (modal.iconEl){
      if (src){
        modal.iconEl.src = src;
        modal.iconEl.alt = label;
        modal.iconEl.style.display = 'block';
      } else {
        modal.iconEl.removeAttribute('src');
        modal.iconEl.alt = '';
        modal.iconEl.style.display = 'none';
      }
    }
  }catch{}
  modal.subtitle.textContent = `Locking in ${secondsLeft} seconds`;
  modal.open();
}

  function cancelPending(){
  if (!pending) return;
  try{ clearInterval(pending.interval); }catch{}
  pending = null;
  setChoiceButtonsEnabled(true);
  // Clear any selected state
  qsa('.is-selected', root).forEach(b => b.classList.remove('is-selected'));
  resetShareUI();

  try{
    if (_cancelModal) _cancelModal.close();
  }catch{}
}

  async function lockChoice(choice, chosen, displayChoice){
    const nextCard = {
      ...card,
      configured: true,
      choice,
      reveal_amount: chosen.amount,
      fields: Number(card.fields || 9)
    };

    // Persist configuration to backend before enabling the recipient link.
    // This avoids intermittent "Not ready yet" on the recipient side when the sender shares too fast.
    const saved = await setConfiguredAndWait(card.token, {
      choice,
      reveal_amount: chosen.amount,
      fields: Number(card.fields || 9),
      card_key: card.card_key
    });

    if (!saved){
      // Keep local mirror for sender UX, but do not enable sharing until server confirms.
      _forcePersistConfiguredCard(card.token, nextCard);
      setChoiceButtonsEnabled(true);
      resetShareUI();
      window.alert('Could not save the card setup yet. Please try again.');
      return;
    }

    // Also keep local mirror aligned (helps if the browser reloads immediately).
    _forcePersistConfiguredCard(card.token, { ...nextCard, ...saved });

    shareUrl = makeAbsoluteCardLink(card.token);
    enableShare();

    // Lock setup after first configuration so the outcome can't be changed accidentally.
    setChoiceButtonsEnabled(false);
    // Mark the selected button
    if (displayChoice === RANDOM_KEY) {
      // Mark the Surprise me button itself
      const surpriseBtn = root.querySelector(`button[data-choice="${RANDOM_KEY}"]`);
      if (surpriseBtn) surpriseBtn.classList.add('is-selected');
    } else {
      const selectedBtn = root.querySelector(`button[data-choice="${choice}"]`);
      if (selectedBtn) selectedBtn.classList.add('is-selected');
    }
  }

  changeBtn.addEventListener('click', cancelPending);

  // If the card is already configured

  // Default state: actions look disabled until a prize is selected
  resetShareUI();

  // If the card is already configured (e.g. returning to the private setup link),
  // show the recipient link immediately and prevent changing the outcome.
  if (card && card.configured){
    shareUrl = makeAbsoluteCardLink(card.token);
    enableShare();
    setChoiceButtonsEnabled(false);
    // Don't mark any button on return visits — we can't distinguish random from direct picks
  }

  qsa('button[data-choice]', root).forEach(btn => {
    btn.addEventListener('click', async () => {
      if (card && card.configured) return;

      // If user clicks again mid-countdown, treat it as a reset.
      if (pending) cancelPending();

      const choice = btn.dataset.choice;

      let chosen = null;
      if (choice === RANDOM_KEY) chosen = pickRandomOption();
      else chosen = getRevealOptions().find(o => o.key === choice) || getRevealOptions()[0];

      // IMPORTANT: persist the actual chosen tier key, not RANDOM_KEY.
      // Some backends treat unknown choice keys as a default and may ignore reveal_amount.
      // By storing the real tier key, the random pick becomes real and stable for the recipient.
      const effectiveChoice = (choice === RANDOM_KEY) ? (chosen?.key || getRevealOptions()[0].key) : choice;

      // Confirm before we start the lock countdown (prevents accidental taps).
      const confirmMsg = (choice === RANDOM_KEY)
        ? 'Confirm Surprise me? This locks a random prize tier and cannot be changed.'
        : `Confirm ${chosen.label}? This locks your choice and cannot be changed.`;

      if (!window.confirm(confirmMsg)) return;

      // Micro-step: brief lock countdown with a Cancel option.
      setChoiceButtonsEnabled(false);

      let secondsLeft = 5;
      showPending(choice, chosen, secondsLeft);

      pending = { interval: null, choice: effectiveChoice, chosen, displayChoice: choice };
      pending.interval = setInterval(async () => {
        secondsLeft -= 1;

        if (!pending) return;

        if (secondsLeft <= 0){
          try{ clearInterval(pending.interval); }catch{}
          const finalChoice = pending.choice;
          const finalChosen = pending.chosen;
          const finalDisplayChoice = pending.displayChoice;
          pending = null;
          try{ if (_cancelModal) _cancelModal.close(); }catch{}
          await lockChoice(finalChoice, finalChosen, finalDisplayChoice);
          return;
        }

        showPending(choice, chosen, secondsLeft);
      }, 1000);
    });
  });

  copyBtn.addEventListener('click', async () => {
    if (!shareUrl) return;
    await safeCopyLink(shareUrl);
    copyBtn.disabled = true;
    copyBtn.style.opacity = '';
    copyBtn.textContent = 'Copied';
    setTimeout(() => { copyBtn.textContent = 'Copy'; copyBtn.disabled = false; copyBtn.style.opacity = '1'; }, 1200);
  });

  if (shareBtn){
    shareBtn.addEventListener('click', async () => {
      if (!shareUrl) return;
      await safeShareLink(shareUrl, 'ChicCanto card');
    });
  }

  // Open recipient link in a new tab/window so the sender can keep setup open.
// IMPORTANT: do not fall back to same-tab navigation, because some in-app browsers
// can return null from window.open() even when they still open a new view.
if (openBtn){
  openBtn.onclick = () => {
    if (!shareUrl) return;
    try{
      window.open(shareUrl, '_blank', 'noopener,noreferrer');
    }catch{
      // If window.open is blocked, we intentionally do nothing here.
      // The user can use Copy/Share instead.
    }
  };
}
}


function renderPreparing(root){
  root.innerHTML = `
    <section class="flow-screen">
      <div class="flow-layout">
        <div class="flow-intro">
          <h1 class="flow-title">Preparing your card…</h1>
          <p class="flow-lead muted panel-meta">Just a moment. We are syncing the card setup.</p>
        </div>
        <section class="flow-panel--combined panel">
          <div style="display:flex;align-items:center;gap:10px;">
            <div aria-hidden="true" style="width:14px;height:14px;border-radius:50%;border:2px solid rgba(255,255,255,.35);border-top-color:rgba(255,255,255,.9);animation:ccspin 0.9s linear infinite;"></div>
            <div class="muted panel-meta">Loading…</div>
          </div>
        </section>
      </div>
    </section>
    <style>
      @keyframes ccspin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
    </style>
  `;
}

function _sleep(ms){ return new Promise(r => setTimeout(r, ms)); }

async function _apiGetCardFresh(token){
  try{
    const url = `/token/${encodeURIComponent(token)}?v=${Date.now()}`;
    const res = await fetch(url, {
      cache: 'no-store',
      headers: { 'cache-control': 'no-cache' }
    });
    if (!res || !res.ok) return null;
    const data = await res.json();
    if (!data || typeof data !== 'object') return null;
    return data;
  }catch(_e){
    return null;
  }
}

async function _waitForConfigured(token, { attempts = 10, baseDelayMs = 450 } = {}){
  for (let i = 0; i < attempts; i++){
    const fresh = await _apiGetCardFresh(token);
    if (fresh && fresh.configured) return fresh;
    // Gentle backoff to give KV time to replicate across edges.
    await _sleep(baseDelayMs + (i * 180));
  }
  return null;
}


function renderNotReady(root, card){
  const url = window.location.href;
  const params = new URLSearchParams(window.location.search);
  const setupParam = params.get('setup') || params.get('setup_key') || params.get('setupKey') || '';
  const tokenParam = params.get('token') || (card && card.token) || '';
  let storedSetup = '';
  if (!setupParam && tokenParam){
    try{ storedSetup = localStorage.getItem(`sc:setup:${tokenParam}`) || ''; }catch(_e){}
  }

  const isRecipientLink = !setupParam;
  const canRecoverSender = isRecipientLink && !!(tokenParam && storedSetup);

  const mainCopy = isRecipientLink
    ? 'This is the recipient link. It cannot be used to set up the card.'
    : 'The sender is still setting it up. Try again in a moment.';

  const senderHint = canRecoverSender
    ? 'If you are the sender on this device, you can jump to your setup link now.'
    : 'If you are the sender, open your setup link (it includes an extra setup code).';

  root.innerHTML = `
    <section class="flow-screen">
      <div class="flow-layout">
        <div class="flow-intro">
          <h1 class="flow-title">Not ready yet</h1>
          <p class="flow-lead muted panel-meta">${mainCopy}</p>
        </div>
        <section class="flow-panel--combined panel panel--glass panel--padded" aria-label="Not ready">
          <div class="panel-meta">
            <div>Step 1</div>
            <div class="flow-panel__hint">${canRecoverSender ? 'Open sender setup' : 'Try again soon'}</div>
          </div>

          <div class="control-grid">
            <div class="actions" style="display:flex; gap:10px; flex-wrap:wrap;">
              ${canRecoverSender
                ? '<button class="btn primary" type="button" data-action="sender">Open sender setup</button>'
                : '<button class="btn primary" type="button" data-action="refresh">Refresh</button>'}
              <button class="btn outline" type="button" data-action="copy">Copy this link</button>
              <button class="btn outline" type="button" data-action="share">Share</button>
            </div>

            <p class="muted small" style="margin-top: 10px;">${senderHint}</p>
          </div>
        </section>
      </div>
    </section>
  `;

  const btnRefresh = root.querySelector('[data-action="refresh"]');
  const btnSender = root.querySelector('[data-action="sender"]');
  const btnCopy = root.querySelector('[data-action="copy"]');
  const btnShare = root.querySelector('[data-action="share"]');

  if (btnRefresh){
    btnRefresh.addEventListener('click', () => window.location.reload());
  }

  if (btnSender){
    btnSender.addEventListener('click', () => {
      if (!tokenParam || !storedSetup) return;
      const next = `${window.location.pathname}?token=${encodeURIComponent(tokenParam)}&setup=${encodeURIComponent(storedSetup)}`;
      window.location.assign(next);
    });
  }

  btnCopy.addEventListener('click', async () => {
    try{
      await navigator.clipboard.writeText(url);
      btnCopy.textContent = 'Copied';
      setTimeout(() => (btnCopy.textContent = 'Copy this link'), 1200);
    }catch(_e){
      window.prompt('Copy this link:', url);
    }
  });

  btnShare.addEventListener('click', async () => {
    try{
      if (navigator.share){
        await navigator.share({ url });
        return;
      }
    }catch(_e){}
    try{
      await navigator.clipboard.writeText(url);
      btnShare.textContent = 'Copied';
      setTimeout(() => (btnShare.textContent = 'Share'), 1200);
    }catch(_e){
      window.prompt('Share this link:', url);
    }
  });
}

function escapeHtml(value){
  return String(value).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[c]));
}

function renderInvalidToken(container, token){
  const safeToken = escapeHtml(token);
  container.innerHTML = `
    <div class="card stack">
      <h2>Link not found</h2>
      <p>This card link does not exist or is incomplete. If you copied it manually, double-check the link.</p>
      <div class="row" style="gap:10px; flex-wrap:wrap;">
        <a class="btn primary" href="/activate/">Go to activation</a>
        <button class="btn" type="button" data-action="copy">Copy this link</button>
      </div>
      <p class="small">Reference: <span class="mono">${safeToken}</span></p>
    </div>
  `;

  const btnCopy = container.querySelector('[data-action="copy"]');
  if (btnCopy){
    btnCopy.addEventListener('click', async () => {
      const ok = await copyText(window.location.href);
      btnCopy.textContent = ok ? 'Copied' : 'Copy failed';
      setTimeout(() => (btnCopy.textContent = 'Copy this link'), 1200);
    });
  }
}



function renderLegendPanel(opt){
  const rows = getRevealOptions().map((o, idx) => {
    const prizeNo = idx + 1;
    const src = tierIconSrc ? tierIconSrc(o.tier) : `/assets/img/${o.tier}.svg`;
    return `
      <div class="prize-row" data-tier="${o.tier}">
        <div class="prize-row__left">
          <div class="prize-row__icon">
            <img src="${src}" alt="${o.tier}" data-inline-svg="true">
          </div>
          <div class="prize-row__label">${o.label} <span class="prize-row__tag" data-role="prize-tag" hidden></span></div>
        </div>
      </div>
    `;
  }).join('');

  return `
    <div class="card-legend panel panel--glass">
      <h2>Match 3 to win</h2>
      <p class="rule-text">Scratch all circles to reveal icons</p>
      <div class="prize-list">
        ${rows}
      </div>
    </div>
  `;
}


function applyCardStageTheme(stageEl, theme){
  if (!stageEl || !theme) return;

  const bg = theme.background || { type: 'none' };

  // Reset
  stageEl.style.backgroundImage = '';
  stageEl.style.backgroundRepeat = '';
  stageEl.style.backgroundSize = '';
  stageEl.style.backgroundPosition = '';
  stageEl.style.backgroundColor = '';
  stageEl.style.removeProperty('--scratch-card-bg');
  stageEl.style.removeProperty('--scratch-card-pattern');
  stageEl.style.removeProperty('--scratch-card-pattern-size');
  stageEl.style.removeProperty('--scratch-card-pattern-opacity');

  // Apply per-card legend panel styling directly on the legend element.
  // IMPORTANT: the legend panel is a sibling of .scratch-stage, so CSS vars set on stageEl will not reach it.
  const cardScreenEl = stageEl.closest('.card-screen') || stageEl.closest('.card-screen__body') || stageEl.parentElement;
  const legendEl = cardScreenEl ? cardScreenEl.querySelector('.card-legend') : null;

  if (legendEl){
    // Clear any previous inline legend styles
    legendEl.style.removeProperty('--legend-panel-bg');
    legendEl.style.removeProperty('--legend-panel-border');
    legendEl.style.removeProperty('--legend-panel-blur');
    legendEl.style.removeProperty('--legend-panel-text');
    legendEl.style.removeProperty('--legend-panel-muted');
    legendEl.style.background = '';
    legendEl.style.borderColor = '';
    legendEl.style.webkitBackdropFilter = '';
    legendEl.style.backdropFilter = '';
    legendEl.style.color = '';
    const _h2 = legendEl.querySelector('h2');
    if (_h2) _h2.style.color = '';
    const _rule = legendEl.querySelector('.rule-text');
    if (_rule) _rule.style.color = '';
    legendEl.querySelectorAll('.prize-row__label').forEach(el => { el.style.color = ''; });

    const legendBg = theme.legendPanelBg || 'rgba(18, 22, 32, .42)';
    const legendBorder = theme.legendPanelBorder || 'rgba(255, 255, 255, .14)';
    const legendBlur = theme.legendPanelBlur || '6px';
    const legendText = theme.legendPanelTextColor || 'rgba(255, 255, 255, 0.92)';
    const legendMuted = theme.legendPanelMutedColor || 'rgba(255, 255, 255, 0.70)';

    // Expose vars for CSS-based styling AND force inline values to beat any glass defaults.
    legendEl.style.setProperty('--legend-panel-bg', legendBg);
    legendEl.style.setProperty('--legend-panel-border', legendBorder);
    legendEl.style.setProperty('--legend-panel-blur', legendBlur);
    legendEl.style.setProperty('--legend-panel-text', legendText);
    legendEl.style.setProperty('--legend-panel-muted', legendMuted);

    legendEl.style.background = legendBg;
    legendEl.style.borderColor = legendBorder;
    legendEl.style.webkitBackdropFilter = `blur(${legendBlur})`;
    legendEl.style.backdropFilter = `blur(${legendBlur})`;

    // Text colors (force) so per-card theme controls the legend typography.
    legendEl.style.color = legendText;
    const h2 = legendEl.querySelector('h2');
    if (h2) h2.style.color = legendText;
    const rule = legendEl.querySelector('.rule-text');
    if (rule) rule.style.color = legendMuted;
    legendEl.querySelectorAll('.prize-row__label').forEach(el => { el.style.color = legendText; });
  }


  const inner = stageEl.querySelector('.scratch-stage__inner');

  if (bg.type === 'image' && bg.imageSrc){
    // Use the stage background for full-cover images.
    stageEl.style.backgroundColor = bg.color || '#000';
    stageEl.style.backgroundImage = `url("${bg.imageSrc}")`;

    stageEl.style.backgroundRepeat = 'no-repeat';
    stageEl.style.backgroundSize = 'cover';
    stageEl.style.backgroundPosition = 'center';

    // Disable the pattern layer.
    if (inner){
      inner.style.backgroundImage = 'none';
      inner.style.opacity = '0';
    }
    return;
  }


  // Default: flat color + optional repeating pattern on inner layer.
  stageEl.style.setProperty('--scratch-card-bg', bg.color || '#1c1e1e');

  if (inner){
    inner.style.opacity = (bg.patternOpacity != null) ? String(bg.patternOpacity) : '1';
  }

  if (bg.patternSrc){
    stageEl.style.setProperty('--scratch-card-pattern', `url("${bg.patternSrc}")`);
  } else {
    stageEl.style.setProperty('--scratch-card-pattern', 'none');
    if (inner) inner.style.opacity = '0';
  }

  if (bg.patternSize){
    stageEl.style.setProperty('--scratch-card-pattern-size', String(bg.patternSize));
  }
}

function renderScratch(root, card){
  const cardKey = String(card?.card_key || '').trim() || 'men-novice1';
  setTileSet(cardKey);

  const theme = getCardTheme(cardKey);
  // Scratch foil (silver default, gold for birthday themes)
  const foil = (theme && theme.foil) ? theme.foil : (String(cardKey).includes('birthday') ? 'gold' : 'silver');
  document.documentElement.dataset.foil = foil;
  const titleSrc = (theme && theme.titleSrc) ? theme.titleSrc : '/assets/cards/men-novice1/title.svg';

  const bgDesktopSrc = (theme && theme.bgDesktopSrc) ? theme.bgDesktopSrc : '/assets/cards/men-novice1/bg-desktop.jpg';
  const bgMobileSrc  = (theme && theme.bgMobileSrc)  ? theme.bgMobileSrc  : bgDesktopSrc;


  renderCardHeaderActions(card, false);
  const shareUrl = makeAbsoluteCardLink(card.token);

  const opt = resolveOptionFromCard(card);
  const winTier = opt.tier || 't1';
  const tiers = uniq(getRevealOptions().map(o => o.tier)).filter(Boolean);
  const total = Math.max(1, Math.min(9, card.fields || 9));

  const generatedBoard = buildMatch3Board(total, winTier, tiers, `${card.token}|${winTier}`);
  const board = (Array.isArray(card.board) && card.board.length === total)
    ? card.board
    : generatedBoard;

  root.innerHTML = `
    <div class="card-screen">
<div class="scratch-fx">
        <span class="scratch-glow"></span>

            <div class="scratch-stage" data-export-root="1">
            <picture class="card-bg" aria-hidden="true" data-export-root="1">
  <source media="(max-width: 720px)" srcset="${bgMobileSrc}">
  <img class="card-bg__img" src="${bgDesktopSrc}" alt="" />
</picture>
              <h1 class="scratch-stage__title card-heading" aria-label="Scratch Match Up Game"><img class="scratch-title-img" src="${titleSrc}" alt="" /></h1>

              <div class="card-screen__body">
                ${renderLegendPanel(opt)}

                <div class="scratch-board">
                <div class="scratch-grid" id="board"></div>
                </div>
              </div>
            </div>
          </div>  

    </div>
  `;

  // Apply per-card visuals (legend panel + any stage vars) after DOM is in place.
  const stageEl = root.querySelector('.scratch-stage');
  if (stageEl) applyCardStageTheme(stageEl, theme || {});

  const boardEl = qs('#board', root);
  const copyLinkTop = root.querySelector('#copyLinkTop');
  if (copyLinkTop) {
    copyLinkTop.addEventListener('click', async () => {
      await safeCopyLink(shareUrl);
    });
  }

  const scratched = new Array(total).fill(false);
  const tileCtrls = new Array(total).fill(null);
  const counts = {};
  let alreadyWon = false;

  // Restore scratch state on refresh (tiles that reached the scratch threshold must stay revealed).
  const restored = Array.isArray(card.scratched_indices) ? card.scratched_indices.filter(n => Number.isInteger(n)) : [];
  for (const idx of restored){
    if (idx >= 0 && idx < total){
      scratched[idx] = true;
      const tier = tierForIndex(idx);
      counts[tier] = (counts[tier] || 0) + 1;
    }
  }

  // Debounced persistence of scratch progress so refresh doesn't re-cover already scratched tiles.
  let scratchSaveTimer = null;
  function persistScratchProgress(){
    if (alreadyWon || card.revealed) return;
    const indices = [];
    for (let k = 0; k < total; k++){
      if (scratched[k]) indices.push(k);
    }
    card.scratched_indices = indices;
    saveCard(card);
  }
  function schedulePersistScratch(){
    if (alreadyWon || card.revealed) return;
    if (scratchSaveTimer) clearTimeout(scratchSaveTimer);
    scratchSaveTimer = setTimeout(persistScratchProgress, 300);
  }
  function cancelPersistScratch(){
    if (scratchSaveTimer){
      clearTimeout(scratchSaveTimer);
      scratchSaveTimer = null;
    }
  }

  // Flush any pending scratch progress on page unload (refresh / navigate away).
  // The 300ms debounce can lose the last scratched tile if the user refreshes
  // during that window. This listener fires synchronously before teardown.
  function _flushScratchOnUnload(){
    if (scratchSaveTimer){
      clearTimeout(scratchSaveTimer);
      scratchSaveTimer = null;
      persistScratchProgress();
    }
  }
  window.addEventListener('beforeunload', _flushScratchOnUnload);

  function tierForIndex(i){ return board[i] || winTier; }

  for (let i = 0; i < total; i++){
    const tier = tierForIndex(i);
    const src = tierIconSrc ? tierIconSrc(tier) : `/assets/img/${tier}.svg`;

    const el = document.createElement('div');
    el.className = 'scratch-tile';
    el.dataset.tier = tier;
    el.innerHTML = `
      <div class="under">
        <div style="display:flex; flex-direction:column; align-items:center; gap:8px;">
          <img src="${src}" alt="${tier}" data-inline-svg="true">
          <span class="sub">scratch</span>
        </div>
      </div>
      <canvas aria-label="scratch tile"></canvas>
    `;
    boardEl.appendChild(el);

    const canvas = el.querySelector('canvas');
    tileCtrls[i] = attachScratchTile(canvas, { onScratched: () => onTileScratched(i, el), hintStyle: 'none' });
    if (scratched[i]){
      el.classList.add('done');
      // Hide the canvas immediately so the foil never flashes on screen.
      // forceReveal (below) will properly clear and resize it after layout.
      canvas.style.opacity = '0';
    }
  }

  // Defer forceReveal until the browser has completed layout.
  // getBoundingClientRect() returns 0×0 if the element hasn't been laid out yet,
  // which makes clearRect(0,0,0,0) a no-op — leaving the foil cover visible.
  // Two nested rAFs guarantee layout + paint have happened.
  requestAnimationFrame(() => { requestAnimationFrame(() => {
    for (let i = 0; i < total; i++){
      if (!scratched[i]) continue;
      try{
        tileCtrls[i].forceReveal();
      }catch(_e){}
      // Restore visibility now that the canvas is properly cleared.
      const c = boardEl.querySelectorAll('.scratch-tile')[i]?.querySelector('canvas');
      if (c) c.style.opacity = '';
    }
  }); });

  void hydrateInlineSvgs(root);

  installRotateGuard(root);

  
  // Exporter (Puppeteer) waits for this flag when present.

  async function markExportReadyWhenStable() {
    try {
      // Wait for fonts (if supported)
      if (document.fonts && document.fonts.ready) {
        await Promise.race([
          document.fonts.ready,
          new Promise((r) => setTimeout(r, 1500))
        ]);
      }

      // Give layout a couple of frames
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));

      // Wait for images inside export root
      const root = document.querySelector('[data-export-root="1"]') || document.querySelector('.scratch-stage') || document.body;
      const imgs = Array.from(root.querySelectorAll('img'));
      await Promise.race([
        Promise.all(imgs.map((img) => img.complete ? Promise.resolve() : new Promise((res) => { img.onload = img.onerror = () => res(); }))),
        new Promise((r) => setTimeout(r, 2000))
      ]);

    } catch {

    }
  }
// Signal to the server exporter that the card is ready to be captured.
  markExportReadyWhenStable();
function clearLegendState(){
    qsa('.prize-row__tag[data-role="prize-tag"]', root).forEach(el => {
      el.hidden = true;
      el.textContent = '';
    });
    qsa('.prize-row.is-winner', root).forEach(el => el.classList.remove('is-winner'));
  }

  function markLegendWinner(tier){
    clearLegendState();
    const winRow = qs(`.prize-row[data-tier="${tier}"]`, root);
    if (winRow){
      winRow.classList.add('is-winner');
      const tag = qs('[data-role="prize-tag"]', winRow);
      if (tag){
        tag.hidden = false;
      }
    }
  }

  function showWinUI(){
    // Show the result in the rules panel only.
    markLegendWinner(opt.tier);

    // Highlight the 3 winning tiles with a glow pulse.
    const allTiles = boardEl.querySelectorAll('.scratch-tile');
    for (let i = 0; i < board.length; i++){
      if (board[i] === winTier && allTiles[i]){
        allTiles[i].classList.add('cc-winner');
      }
    }
  }

  async function onTileScratched(i, el){

    if (scratched[i]) return;

    scratched[i] = true;
    el.classList.add('done');

    schedulePersistScratch();

    const tier = tierForIndex(i);
    counts[tier] = (counts[tier] || 0) + 1;

    if (!alreadyWon && counts[winTier] >= 3){
      alreadyWon = true;
      cancelPersistScratch();
      const scratched_indices = scratched
        .map((v, idx) => v ? idx : -1)
        .filter(idx => idx !== -1);
      card.revealed = true;
      card.board = board;
      card.scratched_indices = scratched_indices;

      // CRITICAL: write revealed state to local storage SYNCHRONOUSLY.
      // onTileScratched is called as fire-and-forget from scratch.js (not awaited).
      // If the user refreshes immediately, the browser can tear down the page
      // before the async setRevealedAndWait reaches its local mirror write.
      // This synchronous write ensures the revealed state survives refresh.
      try{
        const lsKey = `sc:card:${card.token}`;
        const raw = localStorage.getItem(lsKey);
        if (raw){
          const obj = JSON.parse(raw);
          if (obj && typeof obj === 'object'){
            obj.revealed = true;
            obj.revealed_at = new Date().toISOString();
            obj.board = board;
            obj.scratched_indices = scratched_indices;
            localStorage.setItem(lsKey, JSON.stringify(obj));
          }
        }
      }catch(_e){}

      // Now do the full async persist (API + local mirror alignment).
      await setRevealedAndWait(card.token, { board, scratched_indices });
      // Show Save image immediately on reveal (no refresh required)
      renderRevealedActions(getCard(card.token) || card);
      fireWinTurboFlash();
      showWinUI();
    }
  }
}

function renderRevealed(root, card){
  renderRevealedActions(card);

  const cardKey = String(card?.card_key || '').trim() || 'men-novice1';
  setTileSet(cardKey);

  const theme = getCardTheme(cardKey);
  const titleSrc = (theme && theme.titleSrc) ? theme.titleSrc : '/assets/cards/men-novice1/title.svg';
  const bgDesktopSrc = (theme && theme.bgDesktopSrc) ? theme.bgDesktopSrc : '/assets/cards/men-novice1/bg-desktop.jpg';
  const bgMobileSrc  = (theme && theme.bgMobileSrc)  ? theme.bgMobileSrc  : bgDesktopSrc;

  const opt = resolveOptionFromCard(card);
  const winTier = opt.tier || 't1';
  const tiers = uniq(getRevealOptions().map(o => o.tier)).filter(Boolean);
  const total = Math.max(1, Math.min(9, card.fields || 9));

  const generatedBoard = buildMatch3Board(total, winTier, tiers, `${card.token}|${winTier}`);
  const board = (Array.isArray(card.board) && card.board.length === total)
    ? card.board
    : generatedBoard;

  root.innerHTML = `
    <div class="card-screen">
      <div class="scratch-fx">
        <span class="scratch-glow"></span>

        <div class="scratch-stage" data-export-root="1">
          <picture class="card-bg" aria-hidden="true" data-export-root="1">
            <source media="(max-width: 720px)" srcset="${bgMobileSrc}">
            <img class="card-bg__img" src="${bgDesktopSrc}" alt="" />
          </picture>

          <h1 class="scratch-stage__title card-heading" aria-label="Scratch Match Up Game">
            <img class="scratch-title-img" src="${titleSrc}" alt="" />
          </h1>

          <div class="card-screen__body">
            ${renderLegendPanel(opt)}
            <div class="scratch-board">
              <div class="scratch-grid" id="boardStatic"></div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="cc-promo" aria-label="ChicCanto promotion">
      <p class="cc-promo__text">Want to send one back? <a class="cc-promo__link" href="https://www.etsy.com/shop/ChicCanto" target="_blank" rel="noopener noreferrer">etsy.com/shop/ChicCanto</a></p>
    </div>
  `;

  // Apply per-card visuals (legend panel + any stage vars) after DOM is in place.
  const stageEl = root.querySelector('.scratch-stage');
  if (stageEl) applyCardStageTheme(stageEl, theme || {});

  const boardEl = qs('#boardStatic', root);
  for (let i = 0; i < board.length; i++){
    const tier = board[i];
    const src = tierIconSrc(tier);
    const el = document.createElement('div');
    el.className = 'scratch-tile done';
    el.dataset.tier = tier;
    el.innerHTML = `
      <div class="under">
        <div style="display:flex; align-items:center; justify-content:center;">
          <img src="${src}" alt="${tier}" data-inline-svg="true">
        </div>
      </div>
    `;
    boardEl.appendChild(el);
  }

  void hydrateInlineSvgs(root);
  installRotateGuard(root);

  // Legend: highlight the revealed tier only.
  qsa('.prize-row__tag[data-role="prize-tag"]', root).forEach(el => {
    el.hidden = true;
    el.textContent = '';
  });
  qsa('.prize-row.is-winner', root).forEach(el => el.classList.remove('is-winner'));
  const winRow = qs(`.prize-row[data-tier="${opt.tier}"]`, root);
  if (winRow){
    winRow.classList.add('is-winner');
    const tag = qs('[data-role="prize-tag"]', winRow);
    if (tag) tag.hidden = true;
  }
}

export async function bootCard(){
  // Landing page stays dark
  if (document.body.dataset.page === 'landing') {
    document.documentElement.dataset.colorMode = 'dark';
  }

  const container = qs('#app');

  const params = new URLSearchParams(window.location.search);
  let token = getTokenFromUrl();

  // Preview mode is only when explicitly requested and there is no real token in the URL.
  PREVIEW_MODE = params.has('preview') && !token;

  // Public preview: allow scratch without a shareable token in the URL.
  if (!token && PREVIEW_MODE){
    // Keep a stable token per tab session so the preview doesn't reset mid-try.
    const key = 'sc:preview_token';
    let t = '';
    try{ t = sessionStorage.getItem(key) || ''; }catch{}
    if (!TOKEN_RE.test(t)){
      try{
        t = (crypto && crypto.randomUUID) ? crypto.randomUUID() : (Math.random().toString(16).slice(2) + '-0000');
      }catch{
        t = (Math.random().toString(16).slice(2) + '-0000');
      }
      try{ sessionStorage.setItem(key, t); }catch{}
    }
    token = t;

    // Ensure a configured preview card exists (recipient scratch flow only).
    let card0 = ensureCard(token);

    // Check if a specific card_key is requested (e.g., ?preview&card_key=custom-card1)
    const previewCardKey = params.get('card_key') || '';
    if (previewCardKey && card0.card_key !== previewCardKey){
      // Card key changed — reset the preview card so it reconfigures for the new type.
      card0.card_key = previewCardKey;
      card0.configured = false;
      card0.revealed = false;
      card0.message = null;
      card0.visible_title = null;
      card0.from_line = null;
      card0.card_style = null;
      card0.scratch_shape = null;
      card0.choice = null;
      card0.board = null;
      card0.scratched_indices = null;
      saveCard(card0);
    }

    const previewTheme = getCardTheme(card0.card_key);
    const previewGameType = (previewTheme && previewTheme.gameType) || 'match3';

    if (!card0.configured){
      if (previewGameType === 'message'){
        // Message cards: pre-fill with sample text for preview
        card0.visible_title = 'Your Title Here';
        card0.message = 'Your hidden message will appear here!';
        card0.from_line = 'Sarah & Tom';
        card0.card_style = (previewTheme && previewTheme.defaultStyle) || 'stardust';
        card0.scratch_shape = (previewTheme && previewTheme.defaultShape) || 'heart';
        card0.configured = true;
        saveCard(card0);
      } else {
        setConfigured(token, { choice: pickRandomOption().key, reveal_amount: pickRandomOption().amount, fields: Number(card0.fields || 9) });
      }
    }

    const card = getCard(token);
    if (card){
      render(container, token, card);
      return;
    }
    // If storage is blocked and we can't create a card, fall through to the missing-link screen.
  }

  if (!token){
    container.innerHTML = `
      <section class="flow-screen">
        <div class="flow-layout">
          <div class="flow-intro">
            <h1 class="flow-title">Link missing</h1>
            <p class="flow-lead muted panel-meta">
              Open a ChicCanto card link, or preview an example.
            </p>
          </div>

          <section class="panel panel--glass panel--padded" aria-label="Link missing actions">
            <div class="control-grid">
              <a class="btn primary" href="/preview/">Preview</a>
              <a class="btn outline" href="/activate/">Go to activation</a>
            </div>
          </section>
        </div>
      </section>
    `;
    return;
  }

  // If the token doesn't even match expected format, treat as an invalid link immediately.
  if (!TOKEN_RE.test(token)){
    renderInvalidToken(container, token);
    return;
  }

  
  const setupParam = params.get('setup') || params.get('setup_key') || params.get('setupKey') || '';
  // Block the scratch page inside mobile/tablet in-app browsers (recipient view only).
  if (!PREVIEW_MODE && !setupParam && isMobileOrTablet() && isLikelyInAppBrowser()){
    renderInAppBlocked(container, token);
    return;
  }

const storeParam = (params.get('store') || '').toLowerCase();

  // Fast path: local mirror (works for same-device refreshes)
  let card = getCard(token);

  // If we didn't find a local record, try the API (same-origin on live/staging).
  const isForceLocal = storeParam === 'local' || storeParam === 'memory';
  if (!card && !isForceLocal){
    card = await getCardAsync(token);
  }

  if (!card){
    renderInvalidToken(container, token);
    return;
  }

  render(container, token, card);
}

// --- Orientation / minimum tile size guard (mobile) ---

function applyTheme(themeId){
  try{
    const body = document.body;
    // remove existing theme-* classes
    body.className.split(/\s+/).forEach(c => {
      if (c && c.startsWith('theme-')) body.classList.remove(c);
    });
    if (typeof themeId === 'string' && themeId.startsWith('theme-')){
      body.classList.add(themeId);
    }
  }catch{}
}

// Per-card page background: sets CSS custom properties on <body> so the
// background gradient and animated glow layers adapt to the card's mood.
// If the theme doesn't define page values, the CSS defaults (dark theme) remain.
function applyPageTheme(cardKey, cardStyle, { allowDarkMode = false } = {}){
  try{
    // For custom cards with sub-styles, resolve the full theme including style-specific page colors.
    const theme = getResolvedMsgTheme(cardKey, cardStyle) || getCardTheme(cardKey);
    if (!theme) return;

    const root = document.documentElement;

    // Set color mode for UI theming
    const colorMode = theme.colorMode || 'dark';
    root.dataset.colorMode = colorMode;

    if (theme.pageBg){
      root.style.setProperty('--page-bg', theme.pageBg);
      // If only pageBg is set, use it for both stops of the base gradient.
      root.style.setProperty('--page-bg1', theme.pageBg1 || theme.pageBg);
    }

    if (theme.pageGlowA1) root.style.setProperty('--page-glow-a1', theme.pageGlowA1);
    if (theme.pageGlowA2) root.style.setProperty('--page-glow-a2', theme.pageGlowA2);
    if (theme.pageGlowA3) root.style.setProperty('--page-glow-a3', theme.pageGlowA3);
    if (theme.pageGlowB1) root.style.setProperty('--page-glow-b1', theme.pageGlowB1);
    if (theme.pageGlowB2) root.style.setProperty('--page-glow-b2', theme.pageGlowB2);

    if (theme.pageGlowAOpacity != null) root.style.setProperty('--page-glow-a-opacity', String(theme.pageGlowAOpacity));
    if (theme.pageGlowBOpacity != null) root.style.setProperty('--page-glow-b-opacity', String(theme.pageGlowBOpacity));

    // Dark mode: restore dark body background and override CSS variables
    if (allowDarkMode && colorMode === 'dark') {
      document.body.style.background = '';
      document.body.style.backgroundImage = 'url("/assets/img/noise.png"), radial-gradient(1100px 800px at 18% 22%, var(--page-glow-a1), transparent 62%), radial-gradient(1000px 760px at 82% 18%, var(--page-glow-a2), transparent 60%), radial-gradient(900px 700px at 55% 80%, var(--page-glow-a3), transparent 62%), linear-gradient(180deg, var(--page-bg1), var(--page-bg))';
      document.body.style.backgroundRepeat = 'repeat, no-repeat, no-repeat, no-repeat, no-repeat';
      document.body.style.backgroundSize = '260px 260px, auto, auto, auto, auto';
      document.body.style.backgroundAttachment = 'fixed, fixed, fixed, fixed, fixed';
      document.body.style.backgroundBlendMode = 'overlay, normal, normal, normal, normal';
      document.body.style.animation = 'none';
      // Restore dark text/UI variables
      root.style.setProperty('--text', '#eef0f6');
      root.style.setProperty('--muted', 'rgba(238, 240, 246, .72)');
      root.style.setProperty('--muted2', 'rgba(238, 240, 246, .55)');
      root.style.setProperty('--link-color', 'rgba(255, 255, 255, .86)');
      root.style.setProperty('--link-hover', 'rgba(255, 255, 255, .98)');
      root.style.setProperty('--link-underline', 'rgba(255, 255, 255, .35)');
      root.style.setProperty('--glass', 'rgba(18, 20, 28, .45)');
      root.style.setProperty('--stroke', 'rgba(255, 255, 255, .12)');
      root.style.setProperty('--shadow', '0 18px 60px rgba(0, 0, 0, .55)');
      // Show glow layers for dark cards
      document.body.style.setProperty('--page-glow-a-opacity', theme.pageGlowAOpacity || '.9');
      document.body.style.setProperty('--page-glow-b-opacity', theme.pageGlowBOpacity || '.45');
    }
  }catch{}
}

const CC_MIN_TILE_PX = 56;
let rotateGuardInstalled = false;

function ensureRotateOverlay(){
  let el = document.getElementById('rotateOverlay');
  if (el) return el;

  el = document.createElement('div');
  el.id = 'rotateOverlay';
  el.className = 'rotate-overlay';
  el.innerHTML = `
    <div class="rotate-overlay__card" role="dialog" aria-modal="true" aria-label="Rotate device">
      <div class="rotate-overlay__title">Rotate for the best scratch experience</div>
      <div class="rotate-overlay__text">
        This screen is a bit too narrow to scratch comfortably. Turn your phone to landscape.
      </div>
    </div>
  `;
  document.body.appendChild(el);
  return el;
}

function updateRotateGuard(){
  const overlay = ensureRotateOverlay();
  const isPortrait = window.matchMedia && window.matchMedia('(orientation: portrait)').matches;

  // Measure a tile (if present)
  const tile = document.querySelector('.scratch-board .scratch-tile');
  const w = tile ? tile.getBoundingClientRect().width : 999;

  const needsLandscape = !!(isPortrait && w && w < CC_MIN_TILE_PX);
  document.body.classList.toggle('force-landscape', needsLandscape);

  // Keep overlay in DOM; CSS controls visibility
  overlay.setAttribute('aria-hidden', needsLandscape ? 'false' : 'true');
}

function installRotateGuard(){
  ensureRotateOverlay();
  updateRotateGuard();

  if (rotateGuardInstalled) return;
  rotateGuardInstalled = true;

  window.addEventListener('resize', updateRotateGuard, { passive: true });
  window.addEventListener('orientationchange', updateRotateGuard, { passive: true });
}

function prefersReducedMotion(){
  return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

function fireWinTurboFlash(){
  try{
    if (prefersReducedMotion()) return;
    const fx = document.querySelector('.scratch-fx');
    if (!fx) return;

    // Synchronized win sequence (~1.8s):
    // 0ms:    border starts ramping up (CSS transition on custom properties)
    // 0ms:    winning tiles start double pop + glow
    // 700ms:  flash fires (via CSS animation-delay)
    // 1800ms: border ramps back down (class removed, CSS transition eases out)
    fx.classList.remove('cc-win-turbo');
    void fx.offsetWidth;
    fx.classList.add('cc-win-turbo');

    window.setTimeout(() => {
      fx.classList.remove('cc-win-turbo');
    }, 1800);
  } catch(_){}
}